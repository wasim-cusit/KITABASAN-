<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('page-title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="teacher-settings-container">
    <div class="teacher-settings-card">
        <h1 class="teacher-settings-title">Teacher Settings</h1>

        <?php if(session('success')): ?>
            <div class="teacher-settings-success" style="background:#dcfce7;border:1px solid #86efac;color:#166534;padding:0.75rem 1rem;margin-bottom:1rem;"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('teacher.settings.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="teacher-settings-sections">
                <div class="teacher-settings-section">
                    <h2 class="teacher-settings-section-title">Notification Settings</h2>
                    <div class="teacher-settings-options">
                        <label class="teacher-settings-option">
                            <input type="checkbox" name="email_notifications" value="1" <?php if($settings['email_notifications'] ?? true): echo 'checked'; endif; ?>>
                            <span>Email notifications for new enrollments</span>
                        </label>
                        <label class="teacher-settings-option">
                            <input type="checkbox" name="course_updates" value="1" <?php if($settings['course_updates'] ?? true): echo 'checked'; endif; ?>>
                            <span>Course update notifications</span>
                        </label>
                    </div>
                </div>

                <div class="teacher-settings-section">
                    <h2 class="teacher-settings-section-title">Privacy Settings</h2>
                    <div class="teacher-settings-options">
                        <label class="teacher-settings-option">
                            <input type="checkbox" name="show_profile" value="1" <?php if($settings['show_profile'] ?? true): echo 'checked'; endif; ?>>
                            <span>Show my profile to students</span>
                        </label>
                        <label class="teacher-settings-option">
                            <input type="checkbox" name="show_email" value="1" <?php if($settings['show_email'] ?? false): echo 'checked'; endif; ?>>
                            <span>Show email address</span>
                        </label>
                    </div>
                </div>

                <div class="teacher-settings-section">
                    <h2 class="teacher-settings-section-title">Device Management</h2>
                    <div class="teacher-settings-device-block">
                        <p class="teacher-settings-device-desc">
                            You can only access your account from one device at a time. If you need to use a different device, you can request a device reset.
                        </p>
                        <a href="<?php echo e(route('teacher.devices.index')); ?>" class="teacher-settings-device-link">Manage My Devices</a>
                    </div>
                </div>
            </div>

            <div class="teacher-settings-submit-wrap">
                <button type="submit" class="teacher-settings-submit-btn">Save Settings</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/teacher/settings/index.blade.php ENDPATH**/ ?>