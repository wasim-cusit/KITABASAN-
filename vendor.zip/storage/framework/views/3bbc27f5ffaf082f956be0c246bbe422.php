<?php $__env->startSection('title', 'My Courses'); ?>
<?php $__env->startSection('page-title', 'My Courses'); ?>

<?php $__env->startSection('content'); ?>
<div class="teacher-courses-container">
    <div class="teacher-courses-header">
        <h1 class="teacher-courses-header-title">My Courses</h1>
        <a href="<?php echo e(route('teacher.courses.create')); ?>" class="teacher-courses-create-btn">
            Create New Course
        </a>
    </div>

    <?php if($courses->count() > 0): ?>
        <div class="teacher-courses-grid">
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="teacher-courses-card">
                    <div class="teacher-courses-card-cover">
                        <?php if($course->cover_image): ?>
                            <img src="<?php echo e(\Storage::url($course->cover_image)); ?>" alt="<?php echo e($course->title); ?>">
                        <?php endif; ?>
                        <span class="teacher-courses-card-status <?php echo e(in_array($course->status, ['published', 'approved']) ? 'teacher-courses-card-status--published' : 'teacher-courses-card-status--draft'); ?>">
                            <?php echo e(ucfirst($course->status)); ?>

                        </span>
                    </div>
                    <div class="teacher-courses-card-body">
                        <div class="teacher-courses-card-content">
                            <h3 class="teacher-courses-card-title"><?php echo e($course->title); ?></h3>
                            <p class="teacher-courses-card-desc"><?php echo e(Str::limit($course->description, 80)); ?></p>
                        </div>
                        <div class="teacher-courses-card-meta">
                            <span class="teacher-courses-card-grade"><?php echo e(optional(optional($course->subject)->grade)->name ?? '—'); ?> → <?php echo e(optional($course->subject)->name ?? '—'); ?></span>
                            <span class="teacher-courses-card-price <?php echo e($course->is_free ? 'teacher-courses-card-price--free' : 'teacher-courses-card-price--paid'); ?>">
                                <?php echo e($course->is_free ? 'Free' : 'Rs. ' . number_format($course->price, 0)); ?>

                            </span>
                        </div>
                        <div class="teacher-courses-card-actions">
                            <a href="<?php echo e(route('teacher.courses.show', $course->id)); ?>" class="teacher-courses-card-btn teacher-courses-card-btn--primary">
                                Manage
                            </a>
                            <a href="<?php echo e(route('teacher.courses.edit', $course->id)); ?>" class="teacher-courses-card-btn teacher-courses-card-btn--secondary">
                                Edit
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="teacher-courses-pagination">
            <?php echo e($courses->links()); ?>

        </div>
    <?php else: ?>
        <div class="teacher-courses-empty">
            <svg class="teacher-courses-empty-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
            </svg>
            <h3 class="teacher-courses-empty-title">No courses yet</h3>
            <p class="teacher-courses-empty-desc">Create your first course to start teaching</p>
            <a href="<?php echo e(route('teacher.courses.create')); ?>" class="teacher-courses-create-btn">
                Create Your First Course
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/teacher/courses/index.blade.php ENDPATH**/ ?>