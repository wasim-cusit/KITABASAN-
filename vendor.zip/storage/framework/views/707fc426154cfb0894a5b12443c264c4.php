<?php $__env->startSection('title', 'FAQs - KITAB ASAN'); ?>
<?php $__env->startSection('description', 'Find answers to common questions about courses, payments, access, and support at KITAB ASAN.'); ?>
<?php $__env->startSection('keywords', 'faqs, help, support, course access, payments, kitab asan'); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <section class="py-12 sm:py-16">
        <div class="container mx-auto px-4 max-w-5xl">
            <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 sm:px-10 py-8 sm:py-10 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
                    <div class="flex flex-col gap-2">
                        <h1 class="text-2xl sm:text-3xl font-bold">FAQs</h1>
                        <p class="text-blue-100 text-sm sm:text-base">Last updated: <?php echo e(date('M d, Y')); ?></p>
                    </div>
                </div>

                <div class="px-6 sm:px-10 py-8 space-y-4 text-sm sm:text-base text-gray-700">
                    <details class="group border border-gray-200 rounded-xl bg-gray-50 p-5 transition hover:border-blue-200">
                        <summary class="cursor-pointer list-none font-semibold text-gray-900 flex items-center justify-between gap-4">
                            <span>How do I enroll in a course?</span>
                            <span class="text-blue-600 group-open:rotate-180 transition-transform">
                                <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.25a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </summary>
                        <p class="mt-3">Select a course, click “Purchase Course” for paid courses or “Start Free Course” for free courses, then complete the payment or enrollment.</p>
                    </details>

                    <details class="group border border-gray-200 rounded-xl bg-gray-50 p-5 transition hover:border-blue-200">
                        <summary class="cursor-pointer list-none font-semibold text-gray-900 flex items-center justify-between gap-4">
                            <span>When will I get access after payment?</span>
                            <span class="text-blue-600 group-open:rotate-180 transition-transform">
                                <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.25a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </summary>
                        <p class="mt-3">Access is granted automatically after successful payment confirmation. If a payment is pending, please allow a few minutes for processing.</p>
                    </details>

                    <details class="group border border-gray-200 rounded-xl bg-gray-50 p-5 transition hover:border-blue-200">
                        <summary class="cursor-pointer list-none font-semibold text-gray-900 flex items-center justify-between gap-4">
                            <span>Can I get a refund?</span>
                            <span class="text-blue-600 group-open:rotate-180 transition-transform">
                                <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.25a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </summary>
                        <p class="mt-3">Refunds are reviewed according to our Return &amp; Refund Policy. Please submit your request within 10 days of purchase.</p>
                    </details>

                    <details class="group border border-gray-200 rounded-xl bg-gray-50 p-5 transition hover:border-blue-200">
                        <summary class="cursor-pointer list-none font-semibold text-gray-900 flex items-center justify-between gap-4">
                            <span>How can I contact support?</span>
                            <span class="text-blue-600 group-open:rotate-180 transition-transform">
                                <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.25a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </summary>
                        <p class="mt-3">You can contact us using the details below for any issues with courses, access, or payments.</p>
                    </details>

                    <details class="group border border-gray-200 rounded-xl bg-gray-50 p-5 transition hover:border-blue-200">
                        <summary class="cursor-pointer list-none font-semibold text-gray-900 flex items-center justify-between gap-4">
                            <span>Do free courses have limits?</span>
                            <span class="text-blue-600 group-open:rotate-180 transition-transform">
                                <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.25a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </summary>
                        <p class="mt-3">Free courses provide full access to listed content. Some courses may also offer limited previews of paid content.</p>
                    </details>

                    <details class="group border border-gray-200 rounded-xl bg-gray-50 p-5 transition hover:border-blue-200">
                        <summary class="cursor-pointer list-none font-semibold text-gray-900 flex items-center justify-between gap-4">
                            <span>Can I access courses on mobile?</span>
                            <span class="text-blue-600 group-open:rotate-180 transition-transform">
                                <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                    <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.25a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z" clip-rule="evenodd" />
                                </svg>
                            </span>
                        </summary>
                        <p class="mt-3">Yes. KITAB ASAN works on modern mobile browsers for learning on the go.</p>
                    </details>

                    <div class="border-t border-gray-200 pt-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-2">Contact</h2>
                        <p>For assistance, contact us at:</p>
                        <p class="mt-2 text-gray-700">
                            <span class="font-semibold">Address:</span> House No. 12, opposite Masjid Abu Ayub Ansari, Near Abpara Market, University Town, Peshawar.<br>
                            <span class="font-semibold">Phone:</span> 03159427588
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/public/faqs.blade.php ENDPATH**/ ?>