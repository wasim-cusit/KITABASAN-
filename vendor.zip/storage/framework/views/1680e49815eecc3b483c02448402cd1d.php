<?php $__env->startSection('title', $topic->title); ?>
<?php $__env->startSection('page-title', $topic->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-0 lg:px-4">
    <?php if(!$enrollment && !$book->is_free && !$topic->is_free && !$topic->is_preview): ?>
        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-3 lg:p-4 mb-6">
            <p class="text-yellow-800 text-xs lg:text-sm">
                <strong>Premium Content:</strong> This topic requires course purchase.
                <a href="<?php echo e(route('student.courses.show', $book->id)); ?>" class="underline font-semibold">Purchase now</a> to access.
            </p>
        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 lg:grid-cols-4 gap-4 lg:gap-6">
        <!-- Video Player -->
        <div class="lg:col-span-3">
            <div class="bg-white rounded-lg shadow p-4 lg:p-6">
                <div class="mb-4">
                    <a href="<?php echo e(route('student.learning.lesson', ['bookId' => $book->id, 'lessonId' => $lesson->id])); ?>"
                       class="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 text-xs lg:text-sm mb-2">
                        <span aria-hidden="true">←</span>
                        <span>Back to Lesson</span>
                        <span class="text-gray-500">•</span>
                        <span class="text-gray-600 truncate max-w-[12rem]"><?php echo e($lesson->title); ?></span>
                    </a>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <h1 class="text-lg lg:text-2xl font-bold"><?php echo e($topic->title); ?></h1>
                        <div class="flex gap-2">
                            <?php if($topic->is_free): ?>
                                <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">FREE</span>
                            <?php elseif($topic->is_preview): ?>
                                <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">PREVIEW</span>
                            <?php elseif(!$enrollment && !$book->is_free): ?>
                                <a href="<?php echo e(route('student.courses.show', $book->id)); ?>"
                                   class="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded hover:bg-yellow-200">
                                    Unlock
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="bg-black rounded-lg overflow-hidden mb-4" style="position: relative; padding-bottom: 56.25%; height: 0;">
                    <?php
                        $canAccess = $book->is_free || $enrollment || $topic->is_free || $topic->is_preview;
                    ?>
                    <?php if($canAccess): ?>
                        <?php if($topic->video_host === 'youtube' && $topic->video_id): ?>
                            <?php
                                $cleanVideoId = $videoService->extractYouTubeId($topic->video_id);
                                $embedUrl = $videoService->getYouTubeEmbedUrl($cleanVideoId);
                            ?>
                            <?php if(!empty($cleanVideoId) && strlen($cleanVideoId) >= 11): ?>
                                <iframe
                                    src="<?php echo e($embedUrl); ?>?enablejsapi=1"
                                    frameborder="0"
                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen
                                    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;">
                                </iframe>
                            <?php else: ?>
                                <div class="flex items-center justify-center text-white" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                                    <p>Invalid YouTube video ID</p>
                                </div>
                            <?php endif; ?>
                        <?php elseif($topic->video_host === 'bunny' && $topic->video_id): ?>
                            <video controls controlsList="nodownload" oncontextmenu="return false;" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                                <source src="<?php echo e($videoService->getBunnyStreamUrl($topic->video_id, $book->bunny_library_id ?? '')); ?>" type="video/mp4">
                            </video>
                        <?php elseif($topic->video_host === 'upload' && $topic->video_file): ?>
                            <video controls controlsList="nodownload" oncontextmenu="return false;" preload="metadata" id="topicVideoPlayer" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                                <source src="<?php echo e(asset('storage/' . $topic->video_file)); ?>" type="<?php echo e($topic->video_mime_type); ?>">
                                Your browser does not support the video tag.
                            </video>
                            <script>
                                // Prevent video download
                                document.addEventListener('DOMContentLoaded', function() {
                                    const video = document.getElementById('topicVideoPlayer');
                                    if (video) {
                                        // Disable right-click context menu
                                        video.addEventListener('contextmenu', function(e) {
                                            e.preventDefault();
                                            return false;
                                        });
                                        // Prevent keyboard shortcuts
                                        video.addEventListener('keydown', function(e) {
                                            if (e.key === 's' || (e.ctrlKey && e.key === 's')) {
                                                e.preventDefault();
                                                return false;
                                            }
                                        });
                                    }
                                });
                            </script>
                        <?php else: ?>
                            <div class="flex items-center justify-center text-white" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                                <p>No video available</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="flex items-center justify-center text-white bg-gray-800" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
                            <div class="text-center">
                                <svg class="w-16 h-16 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                </svg>
                                <p class="text-lg lg:text-xl font-semibold mb-2">Premium Content</p>
                                <p class="text-gray-400 mb-4 text-sm lg:text-base">Purchase this course to access this topic</p>
                                <a href="<?php echo e(route('student.courses.show', $book->id)); ?>" class="inline-block bg-blue-600 text-white px-4 lg:px-6 py-2 rounded-lg hover:bg-blue-700 text-sm lg:text-base">
                                    Purchase Course
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mb-4">
                    <h2 class="text-base lg:text-lg font-semibold mb-2">Description</h2>
                    <p class="text-gray-700 text-sm lg:text-base"><?php echo e($topic->description ?? 'No description available.'); ?></p>
                </div>

                <!-- Navigation: Previous/Next Topic -->
                <?php if(isset($previousTopic) || isset($nextTopic)): ?>
                    <div class="mt-6 pt-6 border-t flex items-center justify-between">
                        <?php if(isset($previousTopic)): ?>
                            <a href="<?php echo e(route('student.learning.topic', ['bookId' => $book->id, 'lessonId' => $lesson->id, 'topicId' => $previousTopic->id])); ?>"
                               class="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                                </svg>
                                <span class="text-sm font-medium">Previous Topic</span>
                                <span class="text-xs text-gray-500 hidden sm:inline"><?php echo e(\Illuminate\Support\Str::limit($previousTopic->title, 30)); ?></span>
                            </a>
                        <?php else: ?>
                            <div></div>
                        <?php endif; ?>

                        <?php if(isset($nextTopic)): ?>
                            <a href="<?php echo e(route('student.learning.topic', ['bookId' => $book->id, 'lessonId' => $lesson->id, 'topicId' => $nextTopic->id])); ?>"
                               class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                <span class="text-sm font-medium">Next Topic</span>
                                <span class="text-xs opacity-90 hidden sm:inline"><?php echo e(\Illuminate\Support\Str::limit($nextTopic->title, 30)); ?></span>
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                </svg>
                            </a>
                        <?php else: ?>
                            <div></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar -->
        <div class="lg:col-span-1 order-first lg:order-last">
            <div class="bg-white rounded-lg shadow p-3 lg:p-4">
                <h3 class="font-bold mb-4 text-sm lg:text-base">Course Content</h3>
                <div class="space-y-2">
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-4">
                            <h4 class="font-semibold text-sm mb-2"><?php echo e($chapter->title); ?></h4>
                            <div class="space-y-1 pl-4">
                                <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="mb-2">
                                        <a href="<?php echo e(route('student.learning.lesson', ['bookId' => $book->id, 'lessonId' => $chapLesson->id])); ?>"
                                           class="block text-sm <?php echo e($chapLesson->id === $lesson->id ? 'text-blue-600 font-semibold' : 'text-gray-600'); ?>">
                                            <?php echo e($chapLesson->title); ?>

                                        </a>
                                        <?php if($chapLesson->id === $lesson->id && $chapLesson->topics && $chapLesson->topics->count() > 0): ?>
                                            <div class="ml-4 mt-1 space-y-1">
                                                <?php $__currentLoopData = $chapLesson->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('student.learning.topic', ['bookId' => $book->id, 'lessonId' => $chapLesson->id, 'topicId' => $top->id])); ?>"
                                                       class="block text-xs <?php echo e($top->id === $topic->id ? 'text-blue-600 font-semibold' : 'text-gray-500'); ?> hover:text-blue-600 transition-colors">
                                                        • <?php echo e($top->title); ?>

                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/student/learning/topic.blade.php ENDPATH**/ ?>