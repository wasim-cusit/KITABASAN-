

<?php $__env->startSection('title', 'Courses Management'); ?>
<?php $__env->startSection('page-title', 'Courses Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow p-4 lg:p-6">
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4">
        <h2 class="text-xl lg:text-2xl font-bold">All Courses</h2>
        <a href="<?php echo e(route('admin.courses.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm lg:text-base text-center">
            Add New Course
        </a>
    </div>

    <!-- Status Summary -->
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6" data-testid="admin-courses-status-summary">
        <?php
            $baseQuery = request()->except('page', 'status');
            $activeStatus = request('status');
        ?>

        <a href="<?php echo e(route('admin.courses.index', $baseQuery)); ?>"
           class="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition <?php echo e(empty($activeStatus) ? 'ring-2 ring-blue-300' : ''); ?>">
            <div class="text-xs text-slate-600 font-semibold">All</div>
            <div class="text-lg font-bold text-gray-900"><?php echo e($statusSummary['total'] ?? 0); ?></div>
        </a>

        <a href="<?php echo e(route('admin.courses.index', array_merge($baseQuery, ['status' => 'draft']))); ?>"
           class="p-3 rounded-lg border border-amber-200 bg-amber-50/70 hover:bg-amber-50 transition <?php echo e($activeStatus === 'draft' ? 'ring-2 ring-amber-300' : ''); ?>">
            <div class="text-xs text-amber-700 font-semibold">Draft</div>
            <div class="text-lg font-bold text-gray-900"><?php echo e($statusSummary['draft'] ?? 0); ?></div>
        </a>

        <a href="<?php echo e(route('admin.courses.index', array_merge($baseQuery, ['status' => 'pending']))); ?>"
           class="p-3 rounded-lg border border-orange-200 bg-orange-50/70 hover:bg-orange-50 transition <?php echo e($activeStatus === 'pending' ? 'ring-2 ring-orange-300' : ''); ?>">
            <div class="text-xs text-orange-700 font-semibold">Pending</div>
            <div class="text-lg font-bold text-gray-900"><?php echo e($statusSummary['pending'] ?? 0); ?></div>
        </a>

        <a href="<?php echo e(route('admin.courses.index', array_merge($baseQuery, ['status' => 'published']))); ?>"
           class="p-3 rounded-lg border border-emerald-200 bg-emerald-50/70 hover:bg-emerald-50 transition <?php echo e($activeStatus === 'published' ? 'ring-2 ring-emerald-300' : ''); ?>">
            <div class="text-xs text-emerald-700 font-semibold">Published</div>
            <div class="text-lg font-bold text-gray-900"><?php echo e($statusSummary['published'] ?? 0); ?></div>
        </a>

        <a href="<?php echo e(route('admin.courses.index', array_merge($baseQuery, ['status' => 'approved']))); ?>"
           class="p-3 rounded-lg border border-green-200 bg-green-50/70 hover:bg-green-50 transition <?php echo e($activeStatus === 'approved' ? 'ring-2 ring-green-300' : ''); ?>">
            <div class="text-xs text-green-700 font-semibold">Approved</div>
            <div class="text-lg font-bold text-gray-900"><?php echo e($statusSummary['approved'] ?? 0); ?></div>
        </a>

        <a href="<?php echo e(route('admin.courses.index', array_merge($baseQuery, ['status' => 'rejected']))); ?>"
           class="p-3 rounded-lg border border-rose-200 bg-rose-50/70 hover:bg-rose-50 transition <?php echo e($activeStatus === 'rejected' ? 'ring-2 ring-rose-300' : ''); ?>">
            <div class="text-xs text-rose-700 font-semibold">Rejected</div>
            <div class="text-lg font-bold text-gray-900"><?php echo e($statusSummary['rejected'] ?? 0); ?></div>
        </a>
    </div>

    <!-- Filters -->
    <form method="GET" action="<?php echo e(route('admin.courses.index')); ?>" class="mb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <input type="text" name="search" placeholder="Search courses..." value="<?php echo e(request('search')); ?>" 
               class="px-4 py-2 border rounded-lg">
        <select name="status" class="px-4 py-2 border rounded-lg">
            <option value="">All Status</option>
            <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
            <option value="published" <?php echo e(request('status') == 'published' ? 'selected' : ''); ?>>Published</option>
        </select>
        <select name="subject_id" class="px-4 py-2 border rounded-lg">
            <option value="">All Subjects</option>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>" <?php echo e(request('subject_id') == $subject->id ? 'selected' : ''); ?>>
                    <?php echo e($subject->grade->name); ?> - <?php echo e($subject->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700">
            Filter
        </button>
    </form>

    <!-- Courses Table -->
    <div class="overflow-x-auto -mx-4 lg:mx-0">
        <div class="inline-block min-w-full align-middle">
            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Course</th>
                            <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase hidden md:table-cell">Teacher</th>
                            <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase hidden lg:table-cell">Subject</th>
                            <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                            <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-3 lg:px-6 py-4">
                                    <div class="flex items-center">
                                        <?php if($course->cover_image): ?>
                                            <img src="<?php echo e(Storage::url($course->cover_image)); ?>" alt="<?php echo e($course->title); ?>" class="h-10 w-10 lg:h-12 lg:w-12 rounded object-cover mr-2 lg:mr-3">
                                        <?php endif; ?>
                                        <div>
                                            <div class="text-sm font-medium text-gray-900"><?php echo e($course->title); ?></div>
                                            <div class="text-xs text-gray-500 lg:hidden"><?php echo e($course->teacher->name ?? 'N/A'); ?></div>
                                            <div class="text-xs text-gray-500 hidden lg:block"><?php echo e(Str::limit($course->description, 50)); ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm text-gray-500 hidden md:table-cell"><?php echo e($course->teacher->name ?? 'N/A'); ?></td>
                                <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm text-gray-500 hidden lg:table-cell">
                                    <?php echo e($course->subject->grade->name ?? ''); ?> → <?php echo e($course->subject->name ?? 'N/A'); ?>

                                </td>
                                <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <?php if($course->is_free): ?>
                                        <span class="text-green-600 font-semibold">Free</span>
                                    <?php else: ?>
                                        Rs. <?php echo e(number_format($course->price, 2)); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="px-3 lg:px-6 py-4">
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                        <?php echo e($course->status == 'published' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                        <?php echo e(ucfirst($course->status)); ?>

                                    </span>
                                </td>
                                <td class="px-3 lg:px-6 py-4 text-sm font-medium">
                                    <div class="flex flex-col sm:flex-row gap-1 sm:gap-0">
                                        <a href="<?php echo e(route('admin.courses.show', $course->id)); ?>" class="text-blue-600 hover:text-blue-900 sm:mr-3">View</a>
                                        <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="text-indigo-600 hover:text-indigo-900 sm:mr-3">Edit</a>
                                        <?php if($course->status == 'draft'): ?>
                                            <form action="<?php echo e(route('admin.courses.approve', $course->id)); ?>" method="POST" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="text-green-600 hover:text-green-900 sm:mr-3">Approve</button>
                                            </form>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('admin.courses.destroy', $course->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-4 text-center text-gray-500">No courses found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="mt-4">
        <?php echo e($courses->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>