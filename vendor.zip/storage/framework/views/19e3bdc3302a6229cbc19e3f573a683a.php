<?php $__env->startSection('title', 'My Devices'); ?>
<?php $__env->startSection('page-title', 'My Devices'); ?>

<?php $__env->startSection('content'); ?>
<div class="teacher-devices-container">
    <div class="teacher-devices-card">
        <div class="teacher-devices-header">
            <h1 class="teacher-devices-header-title">My Devices</h1>
        </div>

        <!-- Current Active Device -->
        <?php
            $activeDevice = $devices->where('status', 'active')->first();
            $pendingReset = $devices->where('status', 'pending_reset')->first();
        ?>

        <?php if($activeDevice): ?>
            <div class="teacher-devices-active">
                <div class="teacher-devices-active-inner">
                    <div>
                        <h3 class="teacher-devices-active-title">Current Active Device</h3>
                        <p class="teacher-devices-active-detail"><strong>Device:</strong> <?php echo e($activeDevice->device_name ?? 'Unknown Device'); ?></p>
                        <p class="teacher-devices-active-detail"><strong>IP Address:</strong> <?php echo e($activeDevice->ip_address ?? 'N/A'); ?></p>
                        <p class="teacher-devices-active-detail"><strong>Last Used:</strong> <?php echo e($activeDevice->last_used_at ? $activeDevice->last_used_at->format('M d, Y H:i') : 'Never'); ?></p>
                        <p class="teacher-devices-active-detail"><strong>Bound On:</strong> <?php echo e($activeDevice->created_at->format('M d, Y H:i')); ?></p>
                    </div>
                    <div>
                        <span class="teacher-devices-badge teacher-devices-badge--active">Active</span>
                    </div>
                </div>

                <?php if(!$pendingReset): ?>
                    <div class="teacher-devices-reset-block">
                        <h4 class="teacher-devices-reset-title">Need to use a different device?</h4>
                        <p class="teacher-devices-reset-desc">You can request a device reset. Your request will be reviewed by an administrator.</p>
                        <button type="button" onclick="document.getElementById('resetRequestModal').classList.remove('hidden')" class="teacher-devices-reset-btn">
                            Request Device Reset
                        </button>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if($pendingReset): ?>
            <div class="teacher-devices-pending">
                <h3 class="teacher-devices-pending-title">Pending Reset Request</h3>
                <p class="teacher-devices-pending-detail"><strong>Requested On:</strong> <?php echo e($pendingReset->reset_requested_at->format('M d, Y H:i')); ?></p>
                <p class="teacher-devices-pending-detail"><strong>Reason:</strong> <?php echo e($pendingReset->reset_request_reason); ?></p>
                <p class="teacher-devices-pending-note">Your device reset request is pending admin approval. You will be notified once it's approved.</p>
            </div>
        <?php endif; ?>

        <!-- All Devices History -->
        <div class="teacher-devices-history">
            
            <div class="teacher-devices-table-wrap">
                <div class="teacher-devices-table-inner">
                    <div class="teacher-devices-table-outer">
                        <table class="teacher-devices-table">
                            <thead>
                                <tr>
                                    <th>Device Name</th>
                                    <th class="hide-md">IP Address</th>
                                    <th>Status</th>
                                    <th class="hide-lg">Last Used</th>
                                    <th class="hide-lg">Bound On</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div><?php echo e($device->device_name ?? 'Unknown Device'); ?></div>
                                            <div class="teacher-devices-ip-mobile"><?php echo e($device->ip_address ?? 'N/A'); ?></div>
                                        </td>
                                        <td class="whitespace-nowrap hide-md teacher-devices-cell-muted"><?php echo e($device->ip_address ?? 'N/A'); ?></td>
                                        <td>
                                            <?php
                                                $badgeClass = $device->status == 'active' ? 'teacher-devices-badge--active' :
                                                    ($device->status == 'pending_reset' ? 'teacher-devices-badge--pending' :
                                                    ($device->status == 'blocked' ? 'teacher-devices-badge--blocked' : 'teacher-devices-badge--default'));
                                            ?>
                                            <span class="teacher-devices-badge <?php echo e($badgeClass); ?>">
                                                <?php echo e(ucfirst(str_replace('_', ' ', $device->status))); ?>

                                            </span>
                                        </td>
                                        <td class="whitespace-nowrap hide-lg teacher-devices-cell-muted">
                                            <?php echo e($device->last_used_at ? $device->last_used_at->format('M d, Y H:i') : 'Never'); ?>

                                        </td>
                                        <td class="whitespace-nowrap hide-lg teacher-devices-cell-muted">
                                            <?php echo e($device->created_at->format('M d, Y H:i')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="teacher-devices-empty">No devices found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reset Request Modal -->
<div id="resetRequestModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <h3 class="text-xl font-bold mb-4">Request Device Reset</h3>
        <p class="text-sm text-gray-600 mb-4">
            Please provide a reason for requesting a device reset. Your request will be reviewed by an administrator.
        </p>
        <form action="<?php echo e(route('teacher.devices.request-reset')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Reason for Reset</label>
                <textarea name="reason" rows="4" required
                          class="w-full px-3 py-2 border rounded-lg <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          placeholder="e.g., Lost my device, Changed phone, etc."></textarea>
                <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="flex gap-2">
                <button type="submit" class="flex-1 bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700">
                    Submit Request
                </button>
                <button type="button" onclick="document.getElementById('resetRequestModal').classList.add('hidden')"
                        class="flex-1 bg-gray-200 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-300">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/teacher/devices/index.blade.php ENDPATH**/ ?>