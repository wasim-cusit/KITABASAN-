<?php $__env->startSection('title', 'My Profile'); ?>
<?php $__env->startSection('page-title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="teacher-profile-container">
<div class="teacher-profile-card">
    <div class="teacher-profile-header">
        <div class="teacher-profile-hero">
            <?php if($user->profile_image): ?>
                <img src="<?php echo e(\Storage::url($user->profile_image)); ?>" alt="<?php echo e($user->name); ?>" class="teacher-profile-avatar">
            <?php else: ?>
                <div class="teacher-profile-avatar-placeholder"><?php echo e($user->getInitials()); ?></div>
            <?php endif; ?>
            <div>
                <h1 class="teacher-profile-name">
                    <?php echo e(trim(($user->first_name ?? '') . ' ' . ($user->last_name ?? '')) ?: $user->name); ?>

                </h1>
                <p class="teacher-profile-email"><?php echo e($user->email); ?></p>
            </div>
        </div>
        <a href="<?php echo e(route('teacher.profile.edit')); ?>" class="teacher-profile-edit-btn">Edit Profile</a>
    </div>

    <!-- Basic Information -->
    <div class="teacher-profile-section">
        <h2 class="teacher-profile-section-title">Basic Information</h2>
        <div class="teacher-profile-grid">
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">First Name</label>
                <p class="teacher-profile-value"><?php echo e($user->first_name ?? 'N/A'); ?></p>
            </div>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Last Name</label>
                <p class="teacher-profile-value"><?php echo e($user->last_name ?? 'N/A'); ?></p>
            </div>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Email</label>
                <p class="teacher-profile-value"><?php echo e($user->email); ?></p>
            </div>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Mobile</label>
                <p class="teacher-profile-value"><?php echo e($user->mobile ?? 'N/A'); ?></p>
            </div>
            <?php if($user->date_of_birth): ?>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Date of Birth</label>
                <p class="teacher-profile-value"><?php echo e($user->date_of_birth->format('F d, Y')); ?></p>
            </div>
            <?php endif; ?>
            <?php if($profile): ?>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Total Courses</label>
                <p class="teacher-profile-value"><?php echo e($profile->total_courses ?? 0); ?></p>
            </div>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Total Students</label>
                <p class="teacher-profile-value"><?php echo e($profile->total_students ?? 0); ?></p>
            </div>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Rating</label>
                <p class="teacher-profile-value"><?php echo e(number_format($profile->rating ?? 0, 2)); ?> / 5.00</p>
            </div>
            <?php endif; ?>
            <?php if($user->bio || ($profile && $profile->bio)): ?>
            <div class="teacher-profile-field teacher-profile-field--full">
                <label class="teacher-profile-label">Bio</label>
                <p class="teacher-profile-value teacher-profile-value--pre"><?php echo e($profile->bio ?? $user->bio); ?></p>
            </div>
            <?php endif; ?>
            <?php if($profile && $profile->qualifications): ?>
            <div class="teacher-profile-field teacher-profile-field--full">
                <label class="teacher-profile-label">Qualifications</label>
                <p class="teacher-profile-value teacher-profile-value--pre"><?php echo e($profile->qualifications); ?></p>
            </div>
            <?php endif; ?>
            <?php if($profile && $profile->specializations): ?>
            <div class="teacher-profile-field teacher-profile-field--full">
                <label class="teacher-profile-label">Specializations</label>
                <p class="teacher-profile-value"><?php echo e($profile->specializations); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Address Information -->
    <?php if($user->address || $user->city || $user->state || $user->country || $user->postal_code): ?>
    <div class="teacher-profile-section">
        <h2 class="teacher-profile-section-title">Address Information</h2>
        <div class="teacher-profile-grid">
            <?php if($user->address): ?>
            <div class="teacher-profile-field teacher-profile-field--full">
                <label class="teacher-profile-label">Address</label>
                <p class="teacher-profile-value"><?php echo e($user->address); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->city): ?>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">City</label>
                <p class="teacher-profile-value"><?php echo e($user->city); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->state): ?>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">State/Province</label>
                <p class="teacher-profile-value"><?php echo e($user->state); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->country): ?>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Country</label>
                <p class="teacher-profile-value"><?php echo e($user->country); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->postal_code): ?>
            <div class="teacher-profile-field">
                <label class="teacher-profile-label">Postal Code</label>
                <p class="teacher-profile-value"><?php echo e($user->postal_code); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Change Password Section -->
    <div class="teacher-profile-section">
        <h2 class="teacher-profile-section-title">Change Password</h2>
        <form action="<?php echo e(route('teacher.profile.password.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="teacher-profile-password-grid">
                <div>
                    <label class="teacher-profile-label">Current Password</label>
                    <input type="password" name="current_password" required class="teacher-profile-input <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="teacher-profile-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="teacher-profile-label">New Password</label>
                    <input type="password" name="password" required class="teacher-profile-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="teacher-profile-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="teacher-profile-label">Confirm Password</label>
                    <input type="password" name="password_confirmation" required class="teacher-profile-input">
                </div>
            </div>
            <button type="submit" class="teacher-profile-submit-btn">Update Password</button>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/teacher/profile/show.blade.php ENDPATH**/ ?>