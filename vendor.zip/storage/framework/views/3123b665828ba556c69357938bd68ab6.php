

<?php $__env->startSection('title', 'Reports'); ?>
<?php $__env->startSection('page-title', 'Reports & Analytics'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Date Range Filter -->
    <div class="bg-white rounded-lg shadow p-6">
        <form method="GET" action="<?php echo e(route('admin.reports.index')); ?>" class="flex gap-4">
            <input type="date" name="date_from" value="<?php echo e($dateFrom); ?>" class="px-4 py-2 border rounded-lg">
            <input type="date" name="date_to" value="<?php echo e($dateTo); ?>" class="px-4 py-2 border rounded-lg">
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                Apply Filter
            </button>
        </form>
    </div>

    <!-- Statistics -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-sm text-gray-500 mb-2">Total Users</h3>
            <p class="text-3xl font-bold"><?php echo e($userStats['total']); ?></p>
            <div class="mt-2 text-sm">
                <span class="text-gray-600">Teachers: <?php echo e($userStats['teachers']); ?></span><br>
                <span class="text-gray-600">Students: <?php echo e($userStats['students']); ?></span>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-sm text-gray-500 mb-2">Total Courses</h3>
            <p class="text-3xl font-bold"><?php echo e($courseStats['total']); ?></p>
            <div class="mt-2 text-sm">
                <span class="text-green-600">Published: <?php echo e($courseStats['published']); ?></span><br>
                <span class="text-yellow-600">Draft: <?php echo e($courseStats['draft']); ?></span>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-sm text-gray-500 mb-2">Total Revenue</h3>
            <p class="text-3xl font-bold text-green-600">Rs. <?php echo e(number_format($paymentStats['completed'], 2)); ?></p>
            <div class="mt-2 text-sm">
                <span class="text-gray-600">Period: <?php echo e($dateFrom); ?> to <?php echo e($dateTo); ?></span>
            </div>
        </div>
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-sm text-gray-500 mb-2">Payments</h3>
            <p class="text-3xl font-bold"><?php echo e($paymentStats['total']); ?></p>
            <div class="mt-2 text-sm">
                <span class="text-yellow-600">Pending: <?php echo e($paymentStats['pending']); ?></span><br>
                <span class="text-red-600">Failed: <?php echo e($paymentStats['failed']); ?></span>
            </div>
        </div>
    </div>

    <!-- Top Courses -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-bold mb-4">Top Courses by Enrollment</h3>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $topCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between border-b pb-2">
                        <div>
                            <p class="font-medium"><?php echo e($course->title); ?></p>
                            <p class="text-sm text-gray-600"><?php echo e($course->enrollments_count); ?> enrollments</p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No data available</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-bold mb-4">Top Courses by Revenue</h3>
            <div class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $topRevenueCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex items-center justify-between border-b pb-2">
                        <div>
                            <p class="font-medium"><?php echo e($course->title); ?></p>
                            <p class="text-sm text-gray-600">Rs. <?php echo e(number_format($course->total_revenue ?? 0, 2)); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No data available</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>