<?php $__env->startSection('title', 'My Students'); ?>
<?php $__env->startSection('page-title', 'My Students'); ?>

<?php $__env->startSection('content'); ?>
<div class="teacher-students-container">
    <div class="teacher-students-card">
        <div class="teacher-students-header">
            <h2 class="teacher-students-header-title">My Students</h2>
        </div>

        <!-- Search Filter -->
        <form method="GET" action="<?php echo e(route('teacher.students.index')); ?>" class="teacher-students-search">
            <div class="teacher-students-search-inner">
                <input type="text" name="search" placeholder="Search by name, email, or mobile..." value="<?php echo e(request('search')); ?>"
                       class="teacher-students-search-input">
                <button type="submit" class="teacher-students-search-btn">
                    Search
                </button>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('teacher.students.index')); ?>" class="teacher-students-clear-btn">
                        Clear
                    </a>
                <?php endif; ?>
            </div>
        </form>

        <!-- Students Table -->
        <div class="teacher-students-table-wrap">
            <div class="teacher-students-table-inner">
                <div class="teacher-students-table-outer">
                    <table class="teacher-students-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th class="hide-sm">Email</th>
                                <th class="hide-md">Mobile</th>
                                <th>Courses</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="teacher-students-cell-student">
                                            <div class="teacher-students-avatar">
                                                <img src="<?php echo e($student->profile_image ? Storage::url($student->profile_image) : 'https://ui-avatars.com/api/?name=' . urlencode($student->name)); ?>" alt="">
                                            </div>
                                            <div class="teacher-students-name-wrap">
                                                <div class="teacher-students-name"><?php echo e($student->name); ?></div>
                                                <div class="teacher-students-email-mobile"><?php echo e(Str::limit($student->email, 25)); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="whitespace-nowrap hide-sm teacher-students-cell-muted"><?php echo e($student->email); ?></td>
                                    <td class="whitespace-nowrap hide-md teacher-students-cell-muted"><?php echo e($student->mobile ?? 'N/A'); ?></td>
                                    <td>
                                        <span class="teacher-students-badge">
                                            <?php echo e($student->enrollments_count); ?> <?php echo e(Str::plural('course', $student->enrollments_count)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('teacher.students.show', $student->id)); ?>" class="teacher-students-view-link">
                                            View Details
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="teacher-students-empty">
                                        No students found
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <div class="teacher-students-pagination">
            <?php echo e($students->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/teacher/students/index.blade.php ENDPATH**/ ?>