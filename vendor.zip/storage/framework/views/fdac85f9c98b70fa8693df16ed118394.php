<?php $__env->startSection('title', $lesson->title); ?>
<?php $__env->startSection('page-title', $lesson->title); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header with Back Button and Progress -->
                <div class="mb-6">
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-4">
                    <a href="<?php echo e(route('student.learning.index', $book->id)); ?>"
                       class="text-gray-600 hover:text-gray-900 transition-colors">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                        </svg>
                    </a>
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900"><?php echo e($book->title); ?></h1>
                        <p class="text-sm text-gray-600 mt-1">
                            <?php echo e($completedLessons ?? 0); ?> of <?php echo e($totalLessons ?? 0); ?> lessons completed
                        </p>
                    </div>
                </div>
                <div class="flex items-center gap-4">
                    <div class="text-right">
                        <div class="text-sm font-semibold text-gray-700"><?php echo e($progressPercentage ?? 0); ?>% Complete</div>
                        <div class="w-48 bg-gray-200 rounded-full h-2 mt-1">
                            <div class="bg-blue-600 h-2 rounded-full transition-all duration-300"
                                 style="width: <?php echo e($progressPercentage ?? 0); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <!-- Main Content Area -->
            <div class="lg:col-span-3">
                <!-- Video Player -->
                <div class="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                    <div class="bg-black" style="aspect-ratio: 16/9; position: relative; width: 100%; padding-bottom: 56.25%;">
                        <?php
                            $canAccess = $book->is_free
                                || $enrollment
                                || $lesson->is_free
                                || $lesson->is_preview;
                            // Check if lesson has video
                            $hasLessonVideo = ($lesson->video_host === 'youtube' && !empty($lesson->video_id))
                                           || ($lesson->video_host === 'bunny' && !empty($lesson->video_id))
                                           || ($lesson->video_host === 'upload' && !empty($lesson->video_file));
                            // Get first topic with video if lesson doesn't have one
                            $videoTopic = null;
                            if (!$hasLessonVideo && $lesson->topics && $lesson->topics->count() > 0) {
                                $videoTopic = $lesson->topics->first(function($topic) {
                                    return ($topic->video_host === 'youtube' && !empty($topic->video_id))
                                        || ($topic->video_host === 'bunny' && !empty($topic->video_id))
                                        || ($topic->video_host === 'upload' && !empty($topic->video_file));
                                });
                            }
                            $youtubeId = null;
                            $youtubeTitle = null;
                            $youtubeSource = null;
                            if ($canAccess) {
                                if ($hasLessonVideo && $lesson->video_host === 'youtube' && $lesson->video_id) {
                                    $youtubeId = $videoService->extractYouTubeId($lesson->video_id);
                                    $youtubeTitle = $lesson->title;
                                    $youtubeSource = 'Lesson';
                                } elseif (!$hasLessonVideo && $videoTopic && $videoTopic->video_host === 'youtube' && $videoTopic->video_id) {
                                    $youtubeId = $videoService->extractYouTubeId($videoTopic->video_id);
                                    $youtubeTitle = $videoTopic->title;
                                    $youtubeSource = 'Topic';
                                }
                            }
                            $youtubeUrl = $youtubeId ? 'https://www.youtube.com/watch?v=' . $youtubeId : null;
                            $youtubeEmbedUrl = $youtubeId ? $videoService->getYouTubeEmbedUrl($youtubeId) : null;
                        ?>
                        <?php if($canAccess): ?>
                            <?php if($hasLessonVideo): ?>
                                
                                <?php if($lesson->video_host === 'youtube' && $lesson->video_id): ?>
                                    <?php if(!empty($youtubeId) && strlen($youtubeId) >= 11): ?>
                                        <iframe
                                            id="youtube-player-<?php echo e($lesson->id); ?>"
                                            src="<?php echo e($youtubeEmbedUrl); ?>"
                                            frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                            allowfullscreen
                                            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;">
                                        </iframe>
                                        <script>
                                            console.log('YouTube Video Debug:', {
                                                lessonId: <?php echo e($lesson->id); ?>,
                                                videoHost: '<?php echo e($lesson->video_host); ?>',
                                                original: '<?php echo e($lesson->video_id); ?>',
                                                extracted: '<?php echo e($youtubeId); ?>',
                                                embedUrl: '<?php echo e($youtubeEmbedUrl); ?>',
                                                canAccess: <?php echo e($canAccess ? 'true' : 'false'); ?>

                                            });
                                        </script>
                                    <?php else: ?>
                                        <div class="flex items-center justify-center h-full text-white">
                                            <div class="text-center">
                                                <p class="text-gray-400">Invalid YouTube video ID</p>
                                                <p class="text-gray-500 text-sm mt-2">Original: <?php echo e($lesson->video_id); ?></p>
                                                <p class="text-gray-500 text-sm">Extracted: <?php echo e($youtubeId); ?></p>
                                                <p class="text-gray-500 text-sm mt-2">Please check the video ID in the lesson settings</p>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php elseif($lesson->video_host === 'bunny' && $lesson->video_id): ?>
                                    <video controls class="w-full h-full" id="videoPlayer" controlsList="nodownload noplaybackrate" disablePictureInPicture oncontextmenu="return false;">
                                        <source src="<?php echo e($videoService->getBunnyStreamUrl($lesson->video_id, $book->bunny_library_id ?? '')); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php elseif($lesson->video_host === 'upload' && $lesson->video_file): ?>
                                    <video controls class="w-full h-full" id="videoPlayer" controlsList="nodownload noplaybackrate" disablePictureInPicture oncontextmenu="return false;">
                                        <source src="<?php echo e(asset('storage/' . $lesson->video_file)); ?>" type="<?php echo e($lesson->video_mime_type ?? 'video/mp4'); ?>">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php endif; ?>
                            <?php elseif($videoTopic): ?>
                                
                                <?php if($videoTopic->video_host === 'youtube' && $videoTopic->video_id): ?>
                                    <?php if(!empty($youtubeId) && strlen($youtubeId) >= 11): ?>
                                        <iframe
                                            id="youtube-player-topic-<?php echo e($videoTopic->id); ?>"
                                            src="<?php echo e($youtubeEmbedUrl); ?>"
                                            frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                            allowfullscreen
                                            style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;">
                                        </iframe>
                                        <script>
                                            console.log('YouTube Topic Video Debug:', {
                                                topicId: <?php echo e($videoTopic->id); ?>,
                                                videoHost: '<?php echo e($videoTopic->video_host); ?>',
                                                original: '<?php echo e($videoTopic->video_id); ?>',
                                                extracted: '<?php echo e($youtubeId); ?>',
                                                embedUrl: '<?php echo e($youtubeEmbedUrl); ?>'
                                            });
                                        </script>
                                    <?php else: ?>
                                        <div class="flex items-center justify-center h-full text-white">
                                            <div class="text-center">
                                                <p class="text-gray-400">Invalid YouTube video ID: <?php echo e($videoTopic->video_id); ?></p>
                                                <p class="text-gray-500 text-sm mt-2">Please check the video ID in the topic settings</p>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php elseif($videoTopic->video_host === 'bunny' && $videoTopic->video_id): ?>
                                    <video controls class="w-full h-full" id="videoPlayer" controlsList="nodownload noplaybackrate" disablePictureInPicture oncontextmenu="return false;">
                                        <source src="<?php echo e($videoService->getBunnyStreamUrl($videoTopic->video_id, $book->bunny_library_id ?? '')); ?>" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php elseif($videoTopic->video_host === 'upload' && $videoTopic->video_file): ?>
                                    <video controls class="w-full h-full" id="videoPlayer" controlsList="nodownload noplaybackrate" disablePictureInPicture oncontextmenu="return false;">
                                        <source src="<?php echo e(asset('storage/' . $videoTopic->video_file)); ?>" type="<?php echo e($videoTopic->video_mime_type ?? 'video/mp4'); ?>">
                                        Your browser does not support the video tag.
                                    </video>
                                <?php endif; ?>
                            <?php else: ?>
                                
                                <div class="flex items-center justify-center h-full text-white">
                                    <div class="text-center">
                                        <svg class="w-16 h-16 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path>
                                        </svg>
                                        <p class="text-gray-400">No video available for this lesson</p>
                                        <?php if($lesson->topics && $lesson->topics->count() > 0): ?>
                                            <p class="text-gray-500 text-sm mt-2">Check topics below for video content</p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="flex items-center justify-center h-full text-white bg-gray-800">
                                <div class="text-center">
                                <div class="text-center">
                                    <svg class="w-16 h-16 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                    </svg>
                                    <p class="text-xl font-semibold mb-2">Premium Content</p>
                                    <p class="text-gray-400 mb-4">Purchase this course to access this lesson</p>
                                    <a href="<?php echo e(route('student.courses.show', $book->id)); ?>" class="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                                        Purchase Course
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($youtubeId)): ?>
                            <!-- Mask YouTube UI overlays (title/share/logo) -->
                            <div class="absolute top-0 left-0 right-0 h-[60px] bg-black pointer-events-none z-10"></div>
                            <div class="absolute bottom-0 left-0 h-12 w-40 bg-black pointer-events-none z-10"></div>
                            <div class="absolute bottom-0 right-0 h-12 w-40 bg-black pointer-events-none z-10"></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Lesson Details -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <div class="flex items-start justify-between mb-4">
                        <div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-2"><?php echo e($lesson->title); ?></h2>
                            <p class="text-gray-600"><?php echo e($lesson->description ?? 'No description available.'); ?></p>
                        </div>
                        <?php if(auth()->user()->hasRole('teacher') || auth()->user()->hasRole('admin')): ?>
                            <a href="<?php echo e(route('teacher.courses.chapters.lessons.edit', ['bookId' => $book->id, 'chapterId' => $lesson->chapter_id, 'lessonId' => $lesson->id])); ?>"
                               class="text-sm bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded-lg transition-colors">
                                Instructor View
                            </a>
                        <?php endif; ?>
                    </div>

                    <!-- Topics in This Lesson -->
                    <?php if($lesson->topics && $lesson->topics->count() > 0): ?>
                        <div class="mt-6 border-t pt-6">
                            <h3 class="text-lg font-semibold text-gray-900 mb-4">Topics in This Lesson</h3>
                            <div class="space-y-3">
                                <?php $__currentLoopData = $lesson->topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $topicCanAccess = $book->is_free
                                            || $enrollment
                                            || $topic->is_free
                                            || $topic->is_preview;
                                    ?>
                                    <div class="relative flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                                        <?php if(!$topicCanAccess): ?>
                                            <div class="absolute inset-0 bg-white/70 flex items-center justify-center rounded-lg">
                                                <div class="text-center text-gray-700">
                                                    <svg class="w-8 h-8 mx-auto mb-1.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                                                    </svg>
                                                    <p class="text-xs font-semibold">Premium Topic</p>
                                                    <a href="<?php echo e(route('student.courses.show', $book->id)); ?>" class="text-xs underline">Purchase course</a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                        <div class="flex items-center gap-3 flex-1">
                                            <div class="flex-shrink-0">
                                                <?php if($topic->type): ?>
                                                    <span class="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded"><?php echo e(strtoupper($topic->type)); ?></span>
                                                <?php else: ?>
                                                    <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z"></path>
                                                    </svg>
                                                <?php endif; ?>
                                            </div>
                                            <div class="flex-1 min-w-0">
                                                <h4 class="font-medium text-gray-900"><?php echo e($topic->title); ?></h4>
                                                <?php if($topic->description): ?>
                                                    <p class="text-sm text-gray-600 mt-1 line-clamp-1"><?php echo e($topic->description); ?></p>
                                                <?php endif; ?>
                                                <div class="flex items-center gap-2 mt-2">
                                                    <?php if($topic->is_free): ?>
                                                        <span class="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">FREE</span>
                                                    <?php elseif($topic->is_preview): ?>
                                                        <span class="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">PREVIEW</span>
                                                    <?php elseif(!$enrollment && !$book->is_free): ?>
                                                        <a href="<?php echo e(route('student.courses.show', $book->id)); ?>"
                                                           class="text-xs bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded hover:bg-yellow-200">
                                                            Unlock
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if(($topic->video_host === 'youtube' && !empty($topic->video_id)) ||
                                                        ($topic->video_host === 'bunny' && !empty($topic->video_id)) ||
                                                        ($topic->video_host === 'upload' && !empty($topic->video_file))): ?>
                                                        <span class="text-xs text-gray-500 flex items-center gap-1">
                                                            <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                                                <path d="M2 6a2 2 0 012-2h6a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V6zM14.553 7.106A1 1 0 0014 8v4a1 1 0 00.553.894l2 1A1 1 0 0018 13V7a1 1 0 00-1.447-.894l-2 1z"></path>
                                                            </svg>
                                                            Video Available
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($topicCanAccess): ?>
                                            <a href="<?php echo e(route('student.learning.topic', ['bookId' => $book->id, 'lessonId' => $lesson->id, 'topicId' => $topic->id])); ?>"
                                               class="ml-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium whitespace-nowrap">
                                                View Topic
                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('student.courses.show', $book->id)); ?>"
                                               class="ml-4 px-4 py-2 bg-gray-200 text-gray-600 rounded-lg text-sm font-medium whitespace-nowrap text-center hover:bg-gray-300">
                                                Unlock
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Navigation: Previous/Next Lesson -->
                    <div class="mt-6 pt-6 border-t flex items-center justify-between">
                        <?php if(isset($previousLesson)): ?>
                            <a href="<?php echo e(route('student.learning.lesson', ['bookId' => $book->id, 'lessonId' => $previousLesson->id])); ?>"
                               class="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
                                </svg>
                                <span class="text-sm font-medium">Previous Lesson</span>
                                <span class="text-xs text-gray-500 hidden sm:inline"><?php echo e(\Illuminate\Support\Str::limit($previousLesson->title, 30)); ?></span>
                            </a>
                        <?php else: ?>
                            <div></div>
                        <?php endif; ?>

                        <?php if(isset($nextLesson)): ?>
                            <a href="<?php echo e(route('student.learning.lesson', ['bookId' => $book->id, 'lessonId' => $nextLesson->id])); ?>"
                               class="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                                <span class="text-sm font-medium">Next Lesson</span>
                                <span class="text-xs opacity-90 hidden sm:inline"><?php echo e(\Illuminate\Support\Str::limit($nextLesson->title, 30)); ?></span>
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                                </svg>
                            </a>
                        <?php else: ?>
                            <div></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- About This Course -->
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h3 class="text-xl font-bold text-gray-900 mb-4">About this course</h3>
                    <p class="text-gray-700 mb-4"><?php echo e($book->description ?? 'No description available.'); ?></p>
                    <div class="flex flex-wrap gap-3">
                        <?php if($book->difficulty_level): ?>
                            <span class="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium">
                                <?php echo e(ucfirst($book->difficulty_level)); ?> Friendly
                            </span>
                        <?php endif; ?>
                        <?php if($book->total_duration): ?>
                            <span class="px-3 py-1 bg-green-50 text-green-700 rounded-full text-sm font-medium">
                                <?php echo e(round($book->total_duration / 60)); ?> Hours Content
                            </span>
                        <?php endif; ?>
                        <?php if($book->certificate_enabled): ?>
                            <span class="px-3 py-1 bg-purple-50 text-purple-700 rounded-full text-sm font-medium">
                                Certificate Included
                            </span>
                        <?php endif; ?>
                        <span class="px-3 py-1 bg-orange-50 text-orange-700 rounded-full text-sm font-medium">
                            Lifetime Access
                        </span>
                    </div>
                </div>
            </div>

            <!-- Sidebar - Course Content -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-lg shadow-sm p-4 sticky top-4">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="font-bold text-gray-900">Course Content</h3>
                    </div>
                    <p class="text-sm text-gray-600 mb-4">
                        <?php echo e($totalLessons ?? 0); ?> lessons • <?php echo e($completedLessons ?? 0); ?> completed
                    </p>

                    <div class="space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto">
                        <?php if(isset($modules) && $modules->count() > 0): ?>
                            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="module-section">
                                    <button onclick="toggleModule(<?php echo e($module->id); ?>)"
                                            class="w-full flex items-center justify-between p-2 hover:bg-gray-50 rounded-lg transition-colors">
                                        <span class="font-semibold text-sm text-gray-900"><?php echo e($module->title); ?></span>
                                        <svg id="icon-<?php echo e($module->id); ?>" class="w-4 h-4 text-gray-500 transition-transform duration-300 ease-in-out transform-gpu" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                        </svg>
                                    </button>
                                    <div id="module-<?php echo e($module->id); ?>" class="module-content pl-4 mt-1 hidden">
                                        <?php $__currentLoopData = $module->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $canAccess = $book->is_free || $enrollment || $chapLesson->is_free || $chapLesson->is_preview;
                                                    $isCompleted = isset($lessonProgresses[$chapLesson->id]) && $lessonProgresses[$chapLesson->id]->is_completed;
                                                    $isCurrent = $chapLesson->id === $lesson->id;
                                                    $lessonUrl = $canAccess
                                                        ? route('student.learning.lesson', ['bookId' => $book->id, 'lessonId' => $chapLesson->id])
                                                        : route('student.courses.show', $book->id);
                                                ?>
                                                <a href="<?php echo e($lessonUrl); ?>"
                                                   class="flex items-center gap-2 p-2 rounded-lg transition-colors <?php echo e($isCurrent ? 'bg-blue-50 text-blue-700' : ($canAccess ? 'text-gray-700 hover:bg-gray-50' : 'text-gray-400')); ?>">
                                                    <?php if($isCompleted): ?>
                                                        <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                        </svg>
                                                    <?php elseif($isCurrent): ?>
                                                        <svg class="w-5 h-5 text-blue-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                                        </svg>
                                                    <?php else: ?>
                                                        <div class="w-5 h-5 rounded-full border-2 border-gray-300 flex-shrink-0"></div>
                                                    <?php endif; ?>
                                                    <span class="text-sm flex-1 min-w-0">
                                                        <span class="block text-[11px] text-gray-500 truncate"><?php echo e($chapter->title); ?></span>
                                                        <span class="block font-medium truncate"><?php echo e($chapLesson->title); ?></span>
                                                    </span>
                                                    <?php if($chapLesson->duration): ?>
                                                        <span class="text-xs text-gray-500 flex-shrink-0">(<?php echo e(gmdate('i:s', $chapLesson->duration)); ?>)</span>
                                                    <?php elseif(!$canAccess): ?>
                                                        <span class="text-xs text-gray-400 flex-shrink-0">Locked</span>
                                                    <?php endif; ?>
                                                </a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <!-- Show chapters directly if no modules -->
                            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $canAccess = $book->is_free || $enrollment || $chapLesson->is_free || $chapLesson->is_preview;
                                        $isCompleted = isset($lessonProgresses[$chapLesson->id]) && $lessonProgresses[$chapLesson->id]->is_completed;
                                        $isCurrent = $chapLesson->id === $lesson->id;
                                        $lessonUrl = $canAccess
                                            ? route('student.learning.lesson', ['bookId' => $book->id, 'lessonId' => $chapLesson->id])
                                            : route('student.courses.show', $book->id);
                                    ?>
                                    <a href="<?php echo e($lessonUrl); ?>"
                                       class="flex items-center gap-2 p-2 rounded-lg transition-colors <?php echo e($isCurrent ? 'bg-blue-50 text-blue-700' : ($canAccess ? 'text-gray-700 hover:bg-gray-50' : 'text-gray-400')); ?>">
                                        <?php if($isCompleted): ?>
                                            <svg class="w-5 h-5 text-green-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                            </svg>
                                        <?php elseif($isCurrent): ?>
                                            <svg class="w-5 h-5 text-blue-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                            </svg>
                                        <?php else: ?>
                                            <div class="w-5 h-5 rounded-full border-2 border-gray-300 flex-shrink-0"></div>
                                        <?php endif; ?>
                                        <span class="text-sm flex-1 min-w-0">
                                            <span class="block text-[11px] text-gray-500 truncate"><?php echo e($chapter->title); ?></span>
                                            <span class="block font-medium truncate"><?php echo e($chapLesson->title); ?></span>
                                        </span>
                                        <?php if($chapLesson->duration): ?>
                                            <span class="text-xs text-gray-500 flex-shrink-0">(<?php echo e(gmdate('i:s', $chapLesson->duration)); ?>)</span>
                                        <?php elseif(!$canAccess): ?>
                                            <span class="text-xs text-gray-400 flex-shrink-0">Locked</span>
                                        <?php endif; ?>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
(function() {
    'use strict';

    // Error handling wrapper
    function safeExecute(fn) {
        try {
            return fn();
        } catch (error) {
            console.error('Error in lesson page:', error);
            return null;
        }
    }

    function toggleModule(moduleId) {
        safeExecute(function() {
            const content = document.getElementById('module-' + moduleId);
            const icon = document.getElementById('icon-' + moduleId);

            if (content && icon) {
                if (content.classList.contains('hidden')) {
                    content.classList.remove('hidden');
                    icon.style.transform = 'rotate(180deg)';
                } else {
                    content.classList.add('hidden');
                    icon.style.transform = 'rotate(0deg)';
                }
            }
        });
    }

    // Make function globally available
    window.toggleModule = toggleModule;

    // Expand module containing current lesson
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            safeExecute(function() {
                <?php if(isset($modules) && $modules->count() > 0): ?>
                    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $module->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($chapLesson->id === $lesson->id): ?>
                                    // Expand this module
                                    const module<?php echo e($module->id); ?> = document.getElementById('module-<?php echo e($module->id); ?>');
                                    const icon<?php echo e($module->id); ?> = document.getElementById('icon-<?php echo e($module->id); ?>');
                                    if (module<?php echo e($module->id); ?>) {
                                        module<?php echo e($module->id); ?>.classList.remove('hidden');
                                        if (icon<?php echo e($module->id); ?>) {
                                            icon<?php echo e($module->id); ?>.style.transform = 'rotate(180deg)';
                                        }
                                    }
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            });
        });
    } else {
        safeExecute(function() {
            <?php if(isset($modules) && $modules->count() > 0): ?>
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $module->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapLesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($chapLesson->id === $lesson->id): ?>
                                // Expand this module
                                const module<?php echo e($module->id); ?> = document.getElementById('module-<?php echo e($module->id); ?>');
                                const icon<?php echo e($module->id); ?> = document.getElementById('icon-<?php echo e($module->id); ?>');
                                if (module<?php echo e($module->id); ?>) {
                                    module<?php echo e($module->id); ?>.classList.remove('hidden');
                                    if (icon<?php echo e($module->id); ?>) {
                                        icon<?php echo e($module->id); ?>.style.transform = 'rotate(180deg)';
                                    }
                                }
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        });
    }

    // Video progress tracking
    function initVideoTracking() {
        safeExecute(function() {
            const videoPlayer = document.getElementById('videoPlayer');
            if (!videoPlayer) return;

            let lastUpdateTime = 0;

            videoPlayer.addEventListener('timeupdate', function() {
                safeExecute(function() {
                    if (!videoPlayer.duration || videoPlayer.duration === 0) return;

                    const currentTime = Math.floor(videoPlayer.currentTime);
                    const progress = (videoPlayer.currentTime / videoPlayer.duration) * 100;

                    // Update progress every 5 seconds
                    if (currentTime - lastUpdateTime >= 5) {
                        lastUpdateTime = currentTime;
                        fetch('<?php echo e(route("student.learning.progress")); ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                            },
                            body: JSON.stringify({
                                lesson_id: <?php echo e($lesson->id); ?>,
                                watch_percentage: Math.round(progress),
                                last_watched_position: currentTime
                            })
                        }).catch(function(err) {
                            console.error('Progress update failed:', err);
                        });
                    }
                });
            });

            // Mark as completed when video ends
            videoPlayer.addEventListener('ended', function() {
                safeExecute(function() {
                    fetch('<?php echo e(route("student.learning.progress")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({
                            lesson_id: <?php echo e($lesson->id); ?>,
                            watch_percentage: 100,
                            is_completed: true
                        })
                    }).then(function() {
                        // Reload page to update completion status
                        setTimeout(function() {
                            window.location.reload();
                        }, 1000);
                    }).catch(function(err) {
                        console.error('Completion update failed:', err);
                    });
                });
            });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initVideoTracking);
    } else {
        initVideoTracking();
    }
})();
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/student/learning/show.blade.php ENDPATH**/ ?>