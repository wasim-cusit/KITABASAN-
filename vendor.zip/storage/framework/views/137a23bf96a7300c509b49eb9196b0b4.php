

<?php $__env->startSection('title', 'Payments Management'); ?>
<?php $__env->startSection('page-title', 'Payments Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-4 lg:space-y-6">
    <!-- Statistics -->
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        <div class="bg-white rounded-lg shadow p-4">
            <h3 class="text-sm text-gray-500">Total Payments</h3>
            <p class="text-2xl font-bold"><?php echo e($stats['total']); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-4">
            <h3 class="text-sm text-gray-500">Total Revenue</h3>
            <p class="text-2xl font-bold text-green-600">Rs. <?php echo e(number_format($stats['total_revenue'], 2)); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-4">
            <h3 class="text-sm text-gray-500">Pending</h3>
            <p class="text-2xl font-bold text-yellow-600"><?php echo e($stats['pending']); ?></p>
        </div>
        <div class="bg-white rounded-lg shadow p-4">
            <h3 class="text-sm text-gray-500">Failed</h3>
            <p class="text-2xl font-bold text-red-600"><?php echo e($stats['failed']); ?></p>
        </div>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-lg shadow p-4 lg:p-6">
        <form method="GET" action="<?php echo e(route('admin.payments.index')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
            <input type="text" name="search" placeholder="Search..." value="<?php echo e(request('search')); ?>" 
                   class="px-4 py-2 border rounded-lg">
            <select name="status" class="px-4 py-2 border rounded-lg">
                <option value="">All Status</option>
                <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Completed</option>
                <option value="failed" <?php echo e(request('status') == 'failed' ? 'selected' : ''); ?>>Failed</option>
                <option value="refunded" <?php echo e(request('status') == 'refunded' ? 'selected' : ''); ?>>Refunded</option>
            </select>
            <select name="gateway" class="px-4 py-2 border rounded-lg">
                <option value="">All Gateways</option>
                <option value="jazzcash" <?php echo e(request('gateway') == 'jazzcash' ? 'selected' : ''); ?>>JazzCash</option>
                <option value="easypaisa" <?php echo e(request('gateway') == 'easypaisa' ? 'selected' : ''); ?>>EasyPaisa</option>
            </select>
            <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="px-4 py-2 border rounded-lg">
            <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="px-4 py-2 border rounded-lg">
            <button type="submit" class="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 col-span-1 sm:col-span-2 lg:col-span-1">
                Filter
            </button>
        </form>

        <!-- Payments Table -->
        <div class="overflow-x-auto -mx-4 lg:mx-0">
            <div class="inline-block min-w-full align-middle">
                <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Transaction ID</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase hidden md:table-cell">User</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase hidden lg:table-cell">Course</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase hidden lg:table-cell">Gateway</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase hidden md:table-cell">Date</th>
                                <th class="px-3 lg:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-3 lg:px-6 py-4">
                                        <div class="text-xs lg:text-sm font-mono"><?php echo e(Str::limit($payment->transaction_id, 12)); ?></div>
                                        <div class="text-xs text-gray-500 md:hidden mt-1"><?php echo e($payment->user->name); ?></div>
                                    </td>
                                    <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm hidden md:table-cell"><?php echo e($payment->user->name); ?></td>
                                    <td class="px-3 lg:px-6 py-4 text-sm hidden lg:table-cell"><?php echo e(Str::limit($payment->book->title, 30)); ?></td>
                                    <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm font-semibold">Rs. <?php echo e(number_format($payment->amount, 2)); ?></td>
                                    <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm hidden lg:table-cell"><?php echo e(ucfirst($payment->gateway ?? 'N/A')); ?></td>
                                    <td class="px-3 lg:px-6 py-4">
                                        <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                            <?php echo e($payment->status == 'completed' ? 'bg-green-100 text-green-800' : 
                                               ($payment->status == 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                                               ($payment->status == 'failed' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800'))); ?>">
                                            <?php echo e(ucfirst($payment->status)); ?>

                                        </span>
                                    </td>
                                    <td class="px-3 lg:px-6 py-4 whitespace-nowrap text-sm text-gray-500 hidden md:table-cell"><?php echo e($payment->created_at->format('M d, Y')); ?></td>
                                    <td class="px-3 lg:px-6 py-4 text-sm font-medium">
                                        <a href="<?php echo e(route('admin.payments.show', $payment->id)); ?>" class="text-blue-600 hover:text-blue-900">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="px-6 py-4 text-center text-gray-500">No payments found</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <?php echo e($payments->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/admin/payments/index.blade.php ENDPATH**/ ?>