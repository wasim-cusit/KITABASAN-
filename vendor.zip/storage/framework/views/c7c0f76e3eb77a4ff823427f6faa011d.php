

<?php $__env->startSection('title', 'Course Details'); ?>
<?php $__env->startSection('page-title', 'Course Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Course Info -->
    <div class="lg:col-span-2 bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h2 class="text-2xl font-bold"><?php echo e($course->title); ?></h2>
                <p class="text-gray-600"><?php echo e($course->subject->grade->name); ?> → <?php echo e($course->subject->name); ?></p>
            </div>
            <div class="flex gap-2">
                <?php if($course->status == 'draft'): ?>
                    <form action="<?php echo e(route('admin.courses.approve', $course->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
                            Approve & Publish
                        </button>
                    </form>
                <?php endif; ?>
                <a href="<?php echo e(route('admin.courses.edit', $course->id)); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Edit Course
                </a>
            </div>
        </div>

        <?php if($course->cover_image): ?>
            <img src="<?php echo e(Storage::url($course->cover_image)); ?>" alt="<?php echo e($course->title); ?>" class="w-full h-64 object-cover rounded-lg mb-6">
        <?php endif; ?>

        <div class="grid grid-cols-3 gap-4 mb-6">
            <div>
                <span class="text-sm text-gray-500">Status</span>
                <p class="font-semibold">
                    <span class="px-2 py-1 text-xs rounded <?php echo e($course->status == 'published' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                        <?php echo e(ucfirst($course->status)); ?>

                    </span>
                </p>
            </div>
            <div>
                <span class="text-sm text-gray-500">Price</span>
                <p class="font-semibold">
                    <?php if($course->is_free): ?>
                        <span class="text-green-600">Free</span>
                    <?php else: ?>
                        Rs. <?php echo e(number_format($course->price, 2)); ?>

                    <?php endif; ?>
                </p>
            </div>
            <div>
                <span class="text-sm text-gray-500">Duration</span>
                <p class="font-semibold"><?php echo e($course->duration_months); ?> months</p>
            </div>
        </div>

        <div class="mb-6">
            <h3 class="text-lg font-bold mb-2">Description</h3>
            <p class="text-gray-700"><?php echo e($course->description); ?></p>
        </div>

        <!-- Course Content -->
        <div>
            <h3 class="text-lg font-bold mb-4">Course Content</h3>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $course->chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border rounded-lg p-4">
                        <h4 class="font-semibold mb-2"><?php echo e($chapter->title); ?></h4>
                        <?php if($chapter->lessons->count() > 0): ?>
                            <div class="ml-4 space-y-1">
                                <?php $__currentLoopData = $chapter->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="text-sm text-gray-600">• <?php echo e($lesson->title); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No chapters yet</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="space-y-6">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-lg font-bold mb-4">Course Info</h3>
            <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-600">Teacher:</span>
                    <span class="font-semibold"><?php echo e($course->teacher->name ?? 'N/A'); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Total Chapters:</span>
                    <span class="font-semibold"><?php echo e($course->chapters->count()); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Enrollments:</span>
                    <span class="font-semibold"><?php echo e($course->enrollments->count()); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-600">Created:</span>
                    <span class="font-semibold"><?php echo e($course->created_at->format('M d, Y')); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/admin/courses/show.blade.php ENDPATH**/ ?>