

<?php $__env->startSection('title', 'Payment Methods'); ?>
<?php $__env->startSection('page-title', 'Payment Methods Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow">
    <div class="p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-xl font-semibold text-gray-800">Payment Methods</h2>
            <a href="<?php echo e(route('admin.settings.payment-methods.create')); ?>" 
               class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                Add New Payment Method
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Icon</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Code</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Mode</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Transaction Fee</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($method->icon): ?>
                                    <img src="<?php echo e(\Storage::url($method->icon)); ?>" alt="<?php echo e($method->name); ?>" class="h-10 w-10 object-contain">
                                <?php else: ?>
                                    <div class="h-10 w-10 bg-gray-200 rounded flex items-center justify-center text-gray-400">
                                        💳
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-gray-900"><?php echo e($method->name); ?></div>
                                <?php if($method->description): ?>
                                    <div class="text-sm text-gray-500"><?php echo e(\Str::limit($method->description, 50)); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <code class="bg-gray-100 px-2 py-1 rounded"><?php echo e($method->code); ?></code>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs rounded-full <?php echo e($method->is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                                    <?php echo e($method->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <span class="px-2 py-1 text-xs rounded <?php echo e($method->is_sandbox ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'); ?>">
                                    <?php echo e($method->is_sandbox ? 'Sandbox' : 'Production'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php if($method->transaction_fee_percentage > 0 || $method->transaction_fee_fixed > 0): ?>
                                    <?php echo e(number_format($method->transaction_fee_percentage, 2)); ?>% 
                                    <?php if($method->transaction_fee_fixed > 0): ?>
                                        + <?php echo e(number_format($method->transaction_fee_fixed, 2)); ?>

                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-gray-400">Free</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex items-center space-x-2">
                                    <a href="<?php echo e(route('admin.settings.payment-methods.edit', $method->id)); ?>" 
                                       class="text-blue-600 hover:text-blue-900">Edit</a>
                                    <form action="<?php echo e(route('admin.settings.payment-methods.toggle-status', $method->id)); ?>" 
                                          method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <button type="submit" 
                                                class="text-<?php echo e($method->is_active ? 'yellow' : 'green'); ?>-600 hover:text-<?php echo e($method->is_active ? 'yellow' : 'green'); ?>-900">
                                            <?php echo e($method->is_active ? 'Deactivate' : 'Activate'); ?>

                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('admin.settings.payment-methods.destroy', $method->id)); ?>" 
                                          method="POST" class="inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this payment method?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-red-600 hover:text-red-900">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                                <p class="mb-2">No payment methods found.</p>
                                <a href="<?php echo e(route('admin.settings.payment-methods.create')); ?>" class="text-blue-600 hover:text-blue-800">Add your first payment method</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/admin/settings/payment-methods/index.blade.php ENDPATH**/ ?>