<?php
    $seo = \App\Services\SEOService::generateMetaTags([
        'title' => 'All Courses - KITAB ASAN | Browse Online Courses',
        'description' => 'Browse our comprehensive collection of online courses. Find courses by grade, subject, or search by keywords. Free and paid courses available from expert instructors.',
        'keywords' => 'online courses, browse courses, all courses, course catalog, online learning courses, free courses, paid courses, course search, find courses',
        'url' => route('courses.index'),
    ]);

    $breadcrumbSchema = \App\Services\SEOService::generateBreadcrumbSchema([
        ['name' => 'Home', 'url' => route('home')],
        ['name' => 'Courses', 'url' => route('courses.index')],
    ]);
?>

<?php $__env->startSection('title', $seo['title']); ?>
<?php $__env->startSection('description', $seo['description']); ?>
<?php $__env->startSection('keywords', $seo['keywords']); ?>

<?php $__env->startPush('structured_data'); ?>
<script type="application/ld+json">
<?php echo json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT); ?>

</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-50">
    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-16">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Explore Our Courses</h1>
            <p class="text-xl text-blue-100">Discover courses that match your interests and goals</p>
        </div>
    </section>

    <!-- Filters and Search -->
    <section class="bg-white shadow-sm py-6">
        <div class="container mx-auto px-4">
            <form method="GET" action="<?php echo e(route('courses.index')); ?>" class="flex flex-col lg:flex-row gap-4">
                <!-- Search Input -->
                <div class="flex-1 w-full min-w-0">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search courses..."
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Filters Row -->
                <div class="flex flex-col sm:flex-row gap-4 lg:shrink-0">
                    <!-- Grade Filter -->
                    <div class="w-full sm:w-48 lg:w-40">
                        <select name="grade" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
                            <option value="">All Grades</option>
                            <?php $__currentLoopData = $grades ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($grade->id); ?>" <?php echo e(request('grade') == $grade->id ? 'selected' : ''); ?>>
                                    <?php echo e($grade->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Type Filter -->
                    <div class="w-full sm:w-40 lg:w-36">
                        <select name="type" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white">
                            <option value="">All Types</option>
                            <option value="free" <?php echo e(request('type') == 'free' ? 'selected' : ''); ?>>Free</option>
                            <option value="paid" <?php echo e(request('type') == 'paid' ? 'selected' : ''); ?>>Paid</option>
                        </select>
                    </div>

                    <!-- Action Buttons -->
                    <div class="flex gap-2 w-full sm:w-auto">
                        <button type="submit" class="flex-1 sm:flex-none bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-medium transition whitespace-nowrap">
                            Filter
                        </button>
                        <?php if(request()->hasAny(['search', 'grade', 'type'])): ?>
                            <a href="<?php echo e(route('courses.index')); ?>" class="flex-1 sm:flex-none text-center bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 font-medium transition whitespace-nowrap">
                                Clear
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <!-- Courses Grid -->
    <section class="py-12">
        <div class="container mx-auto px-4">
            <?php if($courses->count() > 0): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow">
                        <div class="h-48 bg-gradient-to-br from-blue-400 to-indigo-600 relative">
                            <?php if($course->cover_image): ?>
                                <img src="<?php echo e(\Storage::url($course->cover_image)); ?>"
                                     alt="<?php echo e($course->title); ?> - Course Image"
                                     class="w-full h-full object-cover"
                                     loading="lazy"
                                     onload="this.classList.add('loaded')">
                            <?php endif; ?>
                            <?php if($course->is_free): ?>
                                <span class="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">FREE</span>
                            <?php else: ?>
                                <span class="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">PAID</span>
                            <?php endif; ?>
                        </div>
                        <div class="p-6">
                            <div class="flex items-center mb-2 text-sm text-gray-500">
                                <span><?php echo e($course->subject->grade->name ?? 'General'); ?></span>
                                <span class="mx-2">•</span>
                                <span><?php echo e($course->subject->name ?? 'Course'); ?></span>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900 mb-2 line-clamp-2"><?php echo e($course->title); ?></h3>
                            <p class="text-gray-600 text-sm mb-4 line-clamp-2"><?php echo e(Str::limit($course->description, 100)); ?></p>
                            <div class="flex items-center justify-between mb-4">
                                <?php if($course->teacher): ?>
                                    <div class="flex items-center">
                                        <?php if($course->teacher->profile_image): ?>
                                            <img src="<?php echo e(\Storage::url($course->teacher->profile_image)); ?>" 
                                                 alt="<?php echo e($course->teacher->name); ?>" 
                                                 class="w-8 h-8 rounded-full object-cover mr-2 border border-blue-100">
                                        <?php else: ?>
                                            <div class="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mr-2 border border-blue-100">
                                                <span class="text-white font-semibold text-xs"><?php echo e(substr($course->teacher->name, 0, 1)); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        <span class="text-sm text-gray-600"><?php echo e($course->teacher->name); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="flex items-center justify-between">
                                <div>
                                    <?php if($course->is_free): ?>
                                        <span class="text-green-600 font-bold text-lg">Free</span>
                                    <?php else: ?>
                                        <span class="text-blue-600 font-bold text-lg">Rs. <?php echo e(number_format($course->price, 0)); ?></span>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo e(route('courses.show', $course->id)); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm font-medium">
                                    View Details
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination -->
                <div class="mt-12">
                    <?php echo e($courses->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-16">
                    <svg class="mx-auto h-24 w-24 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                    </svg>
                    <h3 class="text-2xl font-bold text-gray-900 mb-2">No courses found</h3>
                    <p class="text-gray-600 mb-6">Try adjusting your search or filters</p>
                    <a href="<?php echo e(route('courses.index')); ?>" class="inline-block bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700">
                        View All Courses
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/public/courses/index.blade.php ENDPATH**/ ?>