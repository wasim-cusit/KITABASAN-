# Student Course Module Navigation Flow

## 📚 Complete User Journey Flow

### 1. Dashboard - Course Selection
**URL:** `/student/dashboard`  
**View:** `student.dashboard.index`

```
┌─────────────────────────────────────┐
│  Student Dashboard                  │
│  ────────────────────────────────   │
│                                      │
│  My Learning Journey                 │
│  ┌─────────────────────────────┐   │
│  │ Course Card 1                │   │
│  │ ┌─────────────────────────┐ │   │
│  │ │ Course Title            │ │   │
│  │ │ Progress: 45%           │ │   │
│  │ │ [Continue Learning] →   │ │   │
│  │ └─────────────────────────┘ │   │
│  └─────────────────────────────┘   │
│                                      │
│  ┌─────────────────────────────┐   │
│  │ Course Card 2                │   │
│  │ ┌─────────────────────────┐ │   │
│  │ │ Course Title            │ │   │
│  │ │ Progress: 12%           │ │   │
│  │ │ [Continue Learning] →   │ │   │
│  │ └─────────────────────────┘ │   │
│  └─────────────────────────────┘   │
└─────────────────────────────────────┘
         │
         │ Click "Continue Learning"
         ↓
```

**Action:** Student clicks "Continue Learning" button on course card  
**Route:** `GET /student/learning/{bookId}`  
**Controller:** `Student\LearningController::index()`

---

### 2. Course Content Page (Learning Index)
**URL:** `/student/learning/{bookId}`  
**View:** `student.learning.index`

```
┌─────────────────────────────────────────────────────────────┐
│  Course Title                                                │
│  Course Description                                          │
│  ─────────────────────────────────────────────────────────  │
│                                                              │
│  Course Content                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📁 Chapter 1: Introduction                          │   │
│  │    ▼ (Click to expand)                             │   │
│  │    ┌────────────────────────────────────────────┐  │   │
│  │    │ 📄 Lesson 1.1: Getting Started              │  │   │
│  │    │    ▼ (Click to expand)                      │  │   │
│  │    │    ┌────────────────────────────────────┐  │  │   │
│  │    │    │ 📹 Lesson Video (if available)     │  │  │   │
│  │    │    │ 📝 Description                     │  │  │   │
│  │    │    │                                    │  │  │   │
│  │    │    │ Topics:                            │  │  │   │
│  │    │    │ ┌──────────────────────────────┐  │  │  │   │
│  │    │    │ │ 📌 Topic 1.1.1: Basics       │  │  │   │
│  │    │    │ │    ▼ (Click to expand)       │  │  │   │
│  │    │    │ │    ┌──────────────────────┐ │  │  │   │
│  │    │    │ │    │ 📹 Topic Video       │ │  │  │   │
│  │    │    │ │    │ 📝 Description       │ │  │  │   │
│  │    │    │ │    └──────────────────────┘ │  │  │   │
│  │    │    │ └──────────────────────────────┘  │  │   │
│  │    │    │ ┌──────────────────────────────┐  │  │   │
│  │    │    │ │ 📌 Topic 1.1.2: Advanced     │  │  │   │
│  │    │    │ └──────────────────────────────┘  │  │   │
│  │    │    └────────────────────────────────────┘  │   │
│  │    └────────────────────────────────────────────┘  │   │
│  │                                                      │   │
│  │    ┌────────────────────────────────────────────┐  │   │
│  │    │ 📄 Lesson 1.2: Next Steps                   │  │   │
│  │    └────────────────────────────────────────────┘  │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📁 Chapter 2: Advanced Topics                        │   │
│  │    ▼ (Click to expand)                               │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  Sidebar:                                                    │
│  ┌──────────────────────┐                                  │
│  │ Progress: 45%         │                                  │
│  │ Total Chapters: 5     │                                  │
│  │ Total Lessons: 12     │                                  │
│  │ Total Topics: 24      │                                  │
│  └──────────────────────┘                                  │
└─────────────────────────────────────────────────────────────┘
```

**Features:**
- ✅ Collapsible chapters (click to expand/collapse)
- ✅ Collapsible lessons (click to expand/collapse)
- ✅ Collapsible topics (click to expand/collapse)
- ✅ Videos embedded directly in collapsed sections
- ✅ Free content visible, paid content locked
- ✅ Progress tracking sidebar

**Navigation Options:**
1. **Click Chapter Header** → Expands/collapses all lessons in chapter
2. **Click Lesson Header** → Expands/collapses lesson content (video + topics)
3. **Click Topic Header** → Expands/collapses topic video and description
4. **Click Lesson Title Link** → Navigates to dedicated lesson page

---

### 3. Dedicated Lesson Page (Alternative Navigation)
**URL:** `/student/learning/{bookId}/lesson/{lessonId}`  
**View:** `student.learning.show`

```
┌─────────────────────────────────────────────────────────────┐
│  ← Back to Course Content                                    │
│  ─────────────────────────────────────────────────────────  │
│                                                              │
│  Lesson Title                                                │
│  Lesson Description                                          │
│  ─────────────────────────────────────────────────────────  │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📹 Video Player                                      │   │
│  │ ┌────────────────────────────────────────────────┐ │   │
│  │ │                                                  │ │   │
│  │ │     YouTube / Bunny / Uploaded Video            │ │   │
│  │ │                                                  │ │   │
│  │ └────────────────────────────────────────────────┘ │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  Topics in This Lesson                                       │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📌 Topic 1: Introduction                             │   │
│  │    [View Topic] →                                     │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📌 Topic 2: Basics                                    │   │
│  │    [View Topic] →                                     │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  Navigation:                                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ ← Previous Lesson    Next Lesson →                   │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  Sidebar:                                                    │
│  ┌──────────────────────┐                                  │
│  │ Course Chapters      │                                  │
│  │ • Chapter 1          │                                  │
│  │   - Lesson 1.1 ✓    │                                  │
│  │   - Lesson 1.2      │                                  │
│  │ • Chapter 2          │                                  │
│  │   - Lesson 2.1      │                                  │
│  └──────────────────────┘                                  │
└─────────────────────────────────────────────────────────────┘
         │
         │ Click "View Topic" or Topic Title
         ↓
```

**Action:** Student clicks on a topic or "View Topic" button  
**Route:** `GET /student/learning/{bookId}/lesson/{lessonId}/topic/{topicId}`  
**Controller:** `Student\LearningController::showTopic()`

---

### 4. Topic Detail Page
**URL:** `/student/learning/{bookId}/lesson/{lessonId}/topic/{topicId}`  
**View:** `student.learning.topic`

```
┌─────────────────────────────────────────────────────────────┐
│  ← Back to Lesson                                            │
│  ─────────────────────────────────────────────────────────  │
│                                                              │
│  Topic Title                                                 │
│  Topic Description                                           │
│  ─────────────────────────────────────────────────────────  │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📹 Topic Video                                       │   │
│  │ ┌────────────────────────────────────────────────┐ │   │
│  │ │                                                  │ │   │
│  │ │     YouTube / Bunny / Uploaded Video            │ │   │
│  │ │                                                  │ │   │
│  │ └────────────────────────────────────────────────┘ │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  Topic Content                                               │
│  [Topic description and additional content]                 │
│                                                              │
│  Navigation:                                                 │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ ← Previous Topic    Next Topic →                     │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  Sidebar:                                                    │
│  ┌──────────────────────┐                                  │
│  │ Course Chapters      │                                  │
│  │ • Chapter 1          │                                  │
│  │   - Lesson 1.1      │                                  │
│  │     • Topic 1.1.1 ✓ │                                  │
│  │     • Topic 1.1.2   │                                  │
│  └──────────────────────┘                                  │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔄 Complete Navigation Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    STUDENT DASHBOARD                         │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ Course Card                                          │   │
│  │ [Continue Learning] →                                 │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                        │
                        │ Click "Continue Learning"
                        ↓
┌─────────────────────────────────────────────────────────────┐
│              COURSE CONTENT PAGE                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📁 Chapter 1 ▼                                        │   │
│  │    ┌──────────────────────────────────────────────┐ │   │
│  │    │ 📄 Lesson 1.1 ▼                                │ │   │
│  │    │    ┌────────────────────────────────────────┐ │ │   │
│  │    │    │ 📹 Lesson Video                        │ │ │   │
│  │    │    │                                        │ │ │   │
│  │    │    │ 📌 Topics:                            │ │ │   │
│  │    │    │    • Topic 1.1.1 ▼                    │ │ │   │
│  │    │    │      ┌──────────────────────────────┐  │ │ │   │
│  │    │    │      │ 📹 Topic Video              │  │ │ │   │
│  │    │    │      └──────────────────────────────┘  │ │ │   │
│  │    │    │    • Topic 1.1.2 ▼                    │ │ │   │
│  │    │    └────────────────────────────────────────┘ │ │   │
│  │    │                                                 │ │   │
│  │    │ [View Full Lesson] →                           │ │   │
│  │    └──────────────────────────────────────────────┘ │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                        │
                        │ Click "View Full Lesson" or Lesson Title
                        ↓
┌─────────────────────────────────────────────────────────────┐
│                  DEDICATED LESSON PAGE                       │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📹 Lesson Video (Full Screen)                        │   │
│  │                                                        │   │
│  │ Topics in This Lesson:                                │   │
│  │ ┌──────────────────────────────────────────────────┐ │   │
│  │ │ 📌 Topic 1.1.1                                   │ │   │
│  │ │ [View Topic] →                                    │ │   │
│  │ └──────────────────────────────────────────────────┘ │   │
│  │ ┌──────────────────────────────────────────────────┐ │   │
│  │ │ 📌 Topic 1.1.2                                   │ │   │
│  │ │ [View Topic] →                                    │ │   │
│  │ └──────────────────────────────────────────────────┘ │   │
│  │                                                        │   │
│  │ ← Previous Lesson    Next Lesson →                    │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                        │
                        │ Click "View Topic"
                        ↓
┌─────────────────────────────────────────────────────────────┐
│                    TOPIC DETAIL PAGE                         │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📹 Topic Video (Full Screen)                         │   │
│  │                                                        │   │
│  │ Topic Description                                     │   │
│  │                                                        │   │
│  │ ← Previous Topic    Next Topic →                      │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Navigation Features

### 1. **Collapsible Structure**
- **Chapters** → Click to expand/collapse all lessons
- **Lessons** → Click to expand/collapse lesson content
- **Topics** → Click to expand/collapse topic video

### 2. **Multiple Access Points**
- **From Course Content Page:**
  - Expand lesson to see video inline
  - Expand topic to see video inline
  - Click lesson title to go to dedicated lesson page
  - Click topic to go to dedicated topic page

### 3. **Progress Indicators**
- ✅ Checkmark on completed lessons
- Progress percentage bar
- "X% watched" indicator
- Completion status in sidebar

### 4. **Navigation Controls**
- **Back Button** → Returns to previous page
- **Previous/Next Lesson** → Navigate between lessons
- **Previous/Next Topic** → Navigate between topics
- **Sidebar Navigation** → Quick access to all chapters/lessons

### 5. **Access Control**
- **Free Content** → Fully accessible, videos playable
- **Paid Content** → Locked with blur overlay, shows "Purchase to unlock"
- **Enrolled Students** → Full access to all content

---

## 📱 User Actions & Routes

| Action | Route | Controller Method | View |
|--------|-------|-------------------|------|
| View Dashboard | `/student/dashboard` | `DashboardController::index()` | `student.dashboard.index` |
| Click "Continue Learning" | `/student/learning/{bookId}` | `LearningController::index()` | `student.learning.index` |
| Expand Chapter | JavaScript (toggle) | - | Inline |
| Expand Lesson | JavaScript (toggle) | - | Inline |
| Expand Topic | JavaScript (toggle) | - | Inline |
| Click Lesson Title | `/student/learning/{bookId}/lesson/{lessonId}` | `LearningController::show()` | `student.learning.show` |
| Click Topic | `/student/learning/{bookId}/lesson/{lessonId}/topic/{topicId}` | `LearningController::showTopic()` | `student.learning.topic` |
| Update Progress | `/student/learning/progress` (POST) | `LearningController::updateProgress()` | AJAX |

---

## 🔄 Complete Flow Sequence

```
1. Student Dashboard
   └─> Click "Continue Learning" on Course Card
       │
       ↓
2. Course Content Page (/student/learning/{bookId})
   ├─> Click Chapter Header → Expand/Collapse Chapter
   ├─> Click Lesson Header → Expand/Collapse Lesson
   │   ├─> View Lesson Video (inline)
   │   └─> Click Topic Header → Expand/Collapse Topic
   │       └─> View Topic Video (inline)
   │
   └─> Click Lesson Title → Navigate to Lesson Page
       │
       ↓
3. Dedicated Lesson Page (/student/learning/{bookId}/lesson/{lessonId})
   ├─> View Full Lesson Video
   ├─> View Lesson Description
   ├─> Click "View Topic" → Navigate to Topic Page
   ├─> Click "Previous Lesson" → Navigate to Previous
   └─> Click "Next Lesson" → Navigate to Next
       │
       ↓
4. Topic Detail Page (/student/learning/{bookId}/lesson/{lessonId}/topic/{topicId})
   ├─> View Full Topic Video
   ├─> View Topic Description
   ├─> Click "Previous Topic" → Navigate to Previous
   └─> Click "Next Topic" → Navigate to Next
```

---

## ✅ Features Summary

### Course Content Page (`/student/learning/{bookId}`)
- ✅ Collapsible chapters, lessons, and topics
- ✅ Videos embedded directly in collapsed sections
- ✅ Free content visible, paid content locked
- ✅ Progress indicators
- ✅ Quick navigation to dedicated lesson pages

### Dedicated Lesson Page (`/student/learning/{bookId}/lesson/{lessonId}`)
- ✅ Full-screen video player
- ✅ Lesson description
- ✅ List of topics in lesson
- ✅ Previous/Next lesson navigation
- ✅ Sidebar with course structure

### Topic Detail Page (`/student/learning/{bookId}/lesson/{lessonId}/topic/{topicId}`)
- ✅ Full-screen topic video
- ✅ Topic description
- ✅ Previous/Next topic navigation
- ✅ Sidebar with course structure

---

## 🎨 Visual Indicators

### Status Icons
- ✅ **Green Checkmark** → Lesson/Topic completed
- 🔒 **Lock Icon** → Paid content (not enrolled)
- 📹 **Video Icon** → Video available
- 📄 **Document Icon** → Lesson/Topic

### Progress Indicators
- **Progress Bar** → Shows watch percentage
- **"X% watched"** → Text indicator
- **Completion Badge** → Green checkmark on completed items

### Access Indicators
- **FREE Badge** → Green badge on free content
- **PAID Badge** → Yellow badge on paid content
- **Lock Overlay** → Blurred video with lock icon for paid content

---

## 🔗 Quick Reference

### Main Navigation Points
1. **Dashboard** → `/student/dashboard`
2. **Course Content** → `/student/learning/{bookId}`
3. **Lesson Page** → `/student/learning/{bookId}/lesson/{lessonId}`
4. **Topic Page** → `/student/learning/{bookId}/lesson/{lessonId}/topic/{topicId}`

### JavaScript Functions
- `toggleChapter(chapterId)` → Expand/collapse chapter
- `toggleLesson(chapterId, lessonId)` → Expand/collapse lesson
- `toggleTopic(chapterId, lessonId, topicId)` → Expand/collapse topic

---

## 📊 Complete User Journey

```
Dashboard
  │
  ├─> Browse Courses → /student/courses
  │   └─> View Course → /student/courses/{id}
  │       └─> Purchase/Enroll → Payment Flow
  │
  └─> My Courses → Continue Learning
      │
      └─> Course Content Page
          │
          ├─> Expand Chapter → View Lessons
          │   └─> Expand Lesson → View Video + Topics
          │       └─> Expand Topic → View Topic Video
          │
          └─> Click Lesson → Dedicated Lesson Page
              └─> Click Topic → Topic Detail Page
                  └─> Navigate Previous/Next
```

---

**Status:** ✅ Complete and Functional

All navigation paths are working correctly with proper access control and progress tracking.
