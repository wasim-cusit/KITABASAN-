# Chatbot Knowledge Base - Training Guide

This folder contains the chatbot's comprehensive knowledge base in JSON format. The chatbot uses this data to answer user questions across the platform.

## 📁 File Structure

- `knowledge_base.json` - Main knowledge base file containing FAQs, greetings, goodbyes, platform information, and role-specific knowledge
- `README.md` - This documentation file

## 🚀 Quick Start - How to Train the Chatbot

### Option 1: Edit JSON File Directly (Recommended for Quick Updates)

1. Navigate to: `storage/app/public/chatbot/knowledge_base.json`
2. Edit the JSON file with your questions and answers
3. **Important**: Make sure the JSON is valid (check for proper commas, quotes, brackets)
4. The chatbot will automatically reload the updated data on the next request

### Option 2: Through Code (Recommended for Bulk Updates)

Use the `PublicChatbotService` or `ChatbotService` to update programmatically:

```php
use App\Services\PublicChatbotService;

$chatbotService = app(PublicChatbotService::class);
$knowledgeBase = $chatbotService->getKnowledgeBase();

// Add new FAQ
$knowledgeBase['faqs'][] = [
    'question' => ['your question', 'question variation 1', 'question variation 2'],
    'answer' => 'Your comprehensive answer here'
];

// Save the updated knowledge base
$chatbotService->updateKnowledgeBase($knowledgeBase);
```

## 📚 Knowledge Base Structure

The knowledge base JSON file follows this comprehensive structure:

```json
{
    "platform_info": {
        "name": "KITAB ASAN",
        "description": "Platform description",
        "features": ["Feature 1", "Feature 2", ...]
    },
    "faqs": [
        {
            "question": ["question variation 1", "question variation 2", ...],
            "answer": "Comprehensive answer to the question"
        }
    ],
    "student_faqs": [
        {
            "question": ["student-specific question variations"],
            "answer": "Answer tailored for students"
        }
    ],
    "teacher_faqs": [
        {
            "question": ["teacher-specific question variations"],
            "answer": "Answer tailored for teachers"
        }
    ],
    "greetings": {
        "hi": "Hello! Welcome message...",
        "hello": "Hello! Another greeting...",
        ...
    },
    "goodbyes": {
        "thank you": "Response to thank you",
        "bye": "Goodbye message",
        ...
    }
}
```

## 📝 Adding New FAQs

### General FAQs (All Users)

Add to the `faqs` array for questions that apply to all users:

```json
{
    "question": [
        "how to enroll",
        "enrollment process",
        "how do i enroll",
        "sign up for course",
        "join course",
        "register for course"
    ],
    "answer": "To enroll in a course, simply browse our courses page, select the course you're interested in, and click the 'Enroll Now' button. For free courses, enrollment is instant. For paid courses, you'll need to complete the payment process first."
}
```

### Student-Specific FAQs

Add to the `student_faqs` array for questions specific to students:

```json
{
    "question": [
        "my courses",
        "enrolled courses",
        "view my courses",
        "courses i enrolled",
        "my learning"
    ],
    "answer": "You can view all your enrolled courses from your student dashboard. The dashboard shows your active courses, progress for each course, upcoming lessons, completed courses, and certificates earned."
}
```

### Teacher-Specific FAQs

Add to the `teacher_faqs` array for questions specific to teachers:

```json
{
    "question": [
        "create course",
        "how to create course",
        "add new course",
        "course creation",
        "make a course"
    ],
    "answer": "To create a course: 1) Go to your teacher dashboard, 2) Click 'Create New Course', 3) Fill in course details, 4) Add modules and chapters, 5) Create lessons with videos or quizzes, 6) Publish the course."
}
```

## 💡 Tips for Better Training

### 1. Add Multiple Question Variations

Include as many question variations as possible:

```json
"question": [
    "how to enroll",
    "how do i enroll",
    "enrollment process",
    "join course",
    "sign up for course",
    "register for course",
    "how can i join",
    "enroll in course",
    "course enrollment",
    "how to join a course"
]
```

### 2. Use Natural Language

Write questions as users would actually type them:

- ✅ Good: "how do i enroll", "enrollment process", "join course"
- ❌ Bad: "enrollment", "course enrollment process FAQ"

### 3. Include Common Synonyms and Variations

- Different phrasings: "how to", "how do i", "can i", "what is"
- Common misspellings: "enroll", "enrol" (if applicable)
- Related terms: "course", "class", "tutorial", "lesson"

### 4. Comprehensive Answers

Provide detailed, helpful answers:

- ✅ Good: "To enroll in a course, browse our courses page, select the course, click 'Enroll Now'. For free courses, enrollment is instant. For paid courses, complete payment first."
- ❌ Bad: "Click enroll button."

### 5. Categorize by User Type

- Use `faqs` for general questions (all users)
- Use `student_faqs` for student-specific questions
- Use `teacher_faqs` for teacher-specific questions

## 🎯 How the Chatbot Matches Questions

The chatbot uses two methods to match user questions:

1. **Keyword Matching**: Checks if user message contains any question keywords
2. **Similarity Scoring**: Uses `similar_text()` function (similarity > 60% threshold)

### Matching Priority Order:

1. Greetings (hi, hello, hey, etc.)
2. Goodbyes (thank you, bye, etc.)
3. Role-specific FAQs (student_faqs for students, teacher_faqs for teachers)
4. General FAQs (faqs for all users)
5. Contextual responses (based on user data like enrollment count)
6. Fallback response (if no match found)

## 📊 Current Knowledge Base Statistics

The chatbot currently includes:

- ✅ 20+ General FAQs covering platform features, enrollment, payments, certificates, etc.
- ✅ 6+ Student-specific FAQs covering progress tracking, course completion, quizzes, etc.
- ✅ 10+ Teacher-specific FAQs covering course creation, student management, analytics, etc.
- ✅ Multiple greeting variations (hi, hello, hey, good morning, etc.)
- ✅ Multiple goodbye variations (thank you, thanks, bye, etc.)

## 🔧 Advanced Training Techniques

### Add Context-Aware Responses

The chatbot can provide personalized responses based on user context:

- For students: Number of enrollments, completed courses
- For teachers: Number of courses created, total students enrolled

### Monitor and Improve

1. Review conversation logs in `chatbot_conversations` table
2. Identify common questions that aren't covered
3. Add new FAQs based on actual user queries
4. Update answers based on user feedback

## 🚨 Important Notes

1. **JSON Validity**: Always ensure your JSON is valid. Use a JSON validator if needed.
2. **Backup**: Make a backup of `knowledge_base.json` before making bulk changes
3. **Testing**: Test new FAQs after adding them to ensure they work correctly
4. **Case Insensitive**: All matching is case-insensitive, so "How To Enroll" matches "how to enroll"
5. **Special Characters**: Escape special characters in JSON (use `\"` for quotes)

## 📈 Future Enhancements

Consider implementing:

- ✅ Database-backed knowledge base for admin panel editing
- ✅ Machine learning integration (OpenAI, Anthropic, etc.)
- ✅ Conversation context tracking
- ✅ User feedback system to improve responses
- ✅ Analytics dashboard to track common questions
- ✅ Multi-language support
- ✅ Admin interface for easy knowledge base management

## 🆘 Troubleshooting

### Chatbot not responding correctly?

1. Check JSON syntax is valid
2. Verify question variations include the keywords users are typing
3. Lower similarity threshold if needed (in code, default is 60%)
4. Check if the FAQ is in the correct category (faqs, student_faqs, teacher_faqs)

### Want to add more complex responses?

You can enhance the `ChatbotService` class to:
- Use AI APIs (OpenAI GPT, Anthropic Claude, etc.)
- Integrate with external knowledge bases
- Add conversation memory/context
- Implement multi-turn conversations

## 📞 Support

For questions about the chatbot or knowledge base:
- Contact Developer: MUHAMMAD WASIM
- Phone: +92 334 2372772
- WhatsApp: +92 334 2372772

---

**Last Updated**: January 2025
**Version**: 2.0 (Expanded Knowledge Base)
