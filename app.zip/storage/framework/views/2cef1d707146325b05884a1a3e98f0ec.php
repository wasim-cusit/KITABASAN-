<?php $__env->startSection('title', 'My Courses'); ?>
<?php $__env->startSection('page-title', 'My Courses'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-0 lg:px-4">
    <div class="bg-white rounded-lg shadow p-4 lg:p-6">
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-xl lg:text-2xl font-bold">My Courses</h1>
            <a href="<?php echo e(route('student.courses.index')); ?>"
               class="text-sm text-blue-600 hover:text-blue-700">
                Browse Courses
            </a>
        </div>

        <?php if($enrollments->isEmpty()): ?>
            <div class="text-center py-10">
                <p class="text-gray-600 mb-4">You have not enrolled in any courses yet.</p>
                <a href="<?php echo e(route('student.courses.index')); ?>"
                   class="inline-flex items-center px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-sm">
                    Browse Courses
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $course = $enrollment->book;
                        $chapters = $course->chapters ?? collect();
                        $totalLessons = $chapters->sum(fn($ch) => $ch->lessons->count());
                        $completedLessons = $enrollment->lessonProgress
                            ? $enrollment->lessonProgress->where('is_completed', true)->count()
                            : 0;
                        $progressPercentage = $totalLessons > 0
                            ? round(($completedLessons / $totalLessons) * 100)
                            : ($enrollment->progress_percentage ?? 0);
                    ?>

                    <div class="border border-gray-200 rounded-xl p-4 flex flex-col gap-4 bg-white shadow-sm hover:shadow-md transition">
                        <div class="space-y-1">
                            <h3 class="text-base lg:text-lg font-semibold text-gray-900 line-clamp-2"><?php echo e($course->title); ?></h3>
                            <span class="inline-flex items-center px-3 py-1.5 text-xs font-semibold bg-blue-100 text-blue-800">
                                <?php echo e($course->subject->name ?? 'Course'); ?>

                            </span>
                        </div>

                        <div class="flex items-center gap-2 text-xs text-gray-600 flex-wrap">
                            <span class="px-3 py-1.5 font-semibold <?php echo e($course->is_free ? 'bg-green-100 text-green-800' : 'bg-amber-200 text-amber-900'); ?>">
                                <?php echo e($course->is_free ? 'Free' : 'Paid'); ?>

                            </span>
                            <?php if($enrollment->expires_at): ?>
                                <span class="text-gray-500">Access until <?php echo e($enrollment->expires_at->format('M d, Y')); ?></span>
                            <?php else: ?>
                                <span class="text-gray-500">Lifetime access</span>
                            <?php endif; ?>
                        </div>

                        <div class="space-y-2">
                            <div class="flex items-center justify-between text-xs text-gray-500">
                                <span class="uppercase tracking-wide">Progress</span>
                                <span class="font-semibold text-blue-600"><?php echo e($progressPercentage); ?>%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-gradient-to-r from-blue-500 to-blue-600 h-2 rounded-full" style="width: <?php echo e($progressPercentage); ?>%"></div>
                            </div>
                            <div class="text-xs text-gray-500">
                                <?php echo e($completedLessons); ?> of <?php echo e($totalLessons); ?> lessons completed
                            </div>
                        </div>

                        <div class="mt-auto flex items-center justify-between gap-3">
                            <div class="text-xs text-gray-600 truncate">
                                <?php if($course->teacher): ?>
                                    Instructor: <?php echo e($course->teacher->name); ?>

                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('student.learning.index', $course->id)); ?>"
                               class="text-sm text-white bg-blue-600 hover:bg-blue-700 px-3 py-2 rounded-lg whitespace-nowrap">
                                Continue
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/student/courses/my.blade.php ENDPATH**/ ?>