<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('page-title', 'Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-0 lg:px-4">
    <div class="bg-white rounded-lg shadow p-4 lg:p-6">
        <h1 class="text-xl lg:text-2xl font-bold mb-6">Student Settings</h1>

        <?php if(session('success')): ?>
            <div class="mb-4 p-3 rounded bg-green-100 text-green-800"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('student.settings.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="space-y-6">
                <div>
                    <h2 class="text-xl font-semibold mb-4">Notification Settings</h2>
                    <div class="space-y-2">
                        <label class="flex items-center">
                            <input type="checkbox" name="email_enrollment_confirmation" value="1" <?php if($settings->email_enrollment_confirmation ?? true): echo 'checked'; endif; ?> class="mr-2">
                            <span>Email when I enroll in a course</span>
                        </label>
                        <label class="flex items-center">
                            <input type="checkbox" name="email_course_updates" value="1" <?php if($settings->email_course_updates ?? true): echo 'checked'; endif; ?> class="mr-2">
                            <span>Email when a course I'm in is updated</span>
                        </label>
                    </div>
                </div>

                <div>
                    <h2 class="text-xl font-semibold mb-4">Learning Preferences</h2>
                    <div class="space-y-2">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Default Video Playback Speed</label>
                            <select name="video_speed" class="w-full px-3 py-2 border rounded">
                                <option value="0.5">0.5x</option>
                                <option value="0.75">0.75x</option>
                                <option value="1" selected>1x (Normal)</option>
                                <option value="1.25">1.25x</option>
                                <option value="1.5">1.5x</option>
                                <option value="2">2x</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div>
                    <h2 class="text-xl font-semibold mb-4">Device Management</h2>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p class="text-sm text-gray-700 mb-3">
                            You can only access your account from one device at a time. If you need to use a different device, you can request a device reset.
                        </p>
                        <a href="<?php echo e(route('student.devices.index')); ?>" class="inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                            Manage My Devices
                        </a>
                    </div>
                </div>
            </div>

            <div class="mt-6">
                <button type="submit" class="bg-blue-600 text-white px-4 lg:px-6 py-2 rounded hover:bg-blue-700 text-sm lg:text-base">
                    Save Settings
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/student/settings/index.blade.php ENDPATH**/ ?>