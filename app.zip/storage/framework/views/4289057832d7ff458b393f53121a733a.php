<?php $__env->startSection('title', 'My Profile'); ?>
<?php $__env->startSection('page-title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow p-6">
    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-start mb-6 gap-4">
        <div class="flex items-center space-x-4">
            <!-- Profile Picture with Initials Fallback -->
            <?php if($user->profile_image): ?>
                <img src="<?php echo e(\Storage::url($user->profile_image)); ?>"
                     alt="<?php echo e($user->name); ?>"
                     class="h-24 w-24 rounded-full object-cover border-4 border-blue-100">
            <?php else: ?>
                <div class="h-24 w-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-2xl font-bold border-4 border-blue-100">
                    <?php echo e($user->getInitials()); ?>

                </div>
            <?php endif; ?>
            <div>
                <h1 class="text-2xl font-bold text-gray-900">
                    <?php echo e(trim(($user->first_name ?? '') . ' ' . ($user->last_name ?? '')) ?: $user->name); ?>

                </h1>
                <p class="text-sm text-gray-500"><?php echo e($user->email); ?></p>
            </div>
        </div>
        <a href="<?php echo e(route('admin.profile.edit')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            Edit Profile
        </a>
    </div>

    <!-- Basic Information -->
    <div class="border-t pt-6 mb-6">
        <h2 class="text-xl font-bold mb-4">Basic Information</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                <p class="text-gray-900"><?php echo e($user->first_name ?? 'N/A'); ?></p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                <p class="text-gray-900"><?php echo e($user->last_name ?? 'N/A'); ?></p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <p class="text-gray-900"><?php echo e($user->email); ?></p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Mobile</label>
                <p class="text-gray-900"><?php echo e($user->mobile ?? 'N/A'); ?></p>
            </div>
            <?php if($user->date_of_birth): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
                <p class="text-gray-900"><?php echo e($user->date_of_birth->format('F d, Y')); ?></p>
            </div>
            <?php endif; ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <span class="px-2 py-1 text-xs rounded-full <?php echo e($user->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                    <?php echo e(ucfirst($user->status)); ?>

                </span>
            </div>
            <?php if($user->bio): ?>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                <p class="text-gray-900 whitespace-pre-line"><?php echo e($user->bio); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Address Information -->
    <?php if($user->address || $user->city || $user->state || $user->country || $user->postal_code): ?>
    <div class="border-t pt-6 mb-6">
        <h2 class="text-xl font-bold mb-4">Address Information</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <?php if($user->address): ?>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">Address</label>
                <p class="text-gray-900"><?php echo e($user->address); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->city): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">City</label>
                <p class="text-gray-900"><?php echo e($user->city); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->state): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">State/Province</label>
                <p class="text-gray-900"><?php echo e($user->state); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->country): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Country</label>
                <p class="text-gray-900"><?php echo e($user->country); ?></p>
            </div>
            <?php endif; ?>
            <?php if($user->postal_code): ?>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Postal Code</label>
                <p class="text-gray-900"><?php echo e($user->postal_code); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Change Password Section -->
    <div class="border-t pt-6">
        <h2 class="text-xl font-bold mb-4">Change Password</h2>
        <form action="<?php echo e(route('admin.profile.password.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                    <input type="password" name="current_password" required
                           class="w-full px-3 py-2 border rounded-lg <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                    <input type="password" name="password" required
                           class="w-full px-3 py-2 border rounded-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                    <input type="password" name="password_confirmation" required
                           class="w-full px-3 py-2 border rounded-lg">
                </div>
            </div>
            <button type="submit" class="mt-4 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                Update Password
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\coursere\kitabasan-lms\resources\views/admin/profile/show.blade.php ENDPATH**/ ?>